# Crawler Choice – Heritrix or Browsertrix v1.3

Chrome extension for fast, conservative web-archiving crawler selection.

## Decision rule

- Recommend **Browsertrix** only when measured evidence supports a **high-confidence** need for high-fidelity/browser crawling.
- Recommend **Heritrix** when the requirement is low, moderate, ambiguous, or unsupported.
- Gemini Nano is a second opinion. It cannot select Browsertrix without measured technical evidence.

## Sampling

1. The **current tab URL is always included as a sample**.
2. Sampling is deterministic, never random.
3. Samples prioritize the front page, distinct section/landing pages, detail/article pages, and useful central pages.
4. Sitemap URLs and actual front-page navigation links are combined so section pages can be sampled even when a sitemap mainly contains detail URLs.
5. Sampling stays on the same registrable domain and ignores redirects outside it.

## Sitemap discovery

The extension reuses the broad sitemap-finder strategy developed for the crawler-preparation tooling:

- every `Sitemap:` line in `robots.txt`, case-insensitive
- common locations such as `/sitemap.xml`, `/Sitemap.xml`, `/sitemap_index.xml`, `/sitemap-index.xml`, `/wp-sitemap.xml`, `/sitemaps.xml`, `/sitemap.txt`, nested sitemap paths, and `.xml.gz` variants
- redirects and arbitrary/query-string/extensionless sitemap URLs discovered through robots or sitemap indexes
- gzip sitemap files
- recursive sitemap indexes
- structurally valid empty XML sitemaps/indexes are retained
- duplicate sitemap content is parsed once while all discovered sitemap locations remain visible
- every fetched content sitemap contributes up to the first **10 suitable page URLs** to the structural sampling candidate pool
- when only a manageable number of child sitemaps exist, the extension tries to inspect all useful ones; huge sitemap indexes are bounded and sampled deterministically to protect runtime
- sitemap expansion scales with the selected 5–20 page sample count, is capped at 40 child sitemap fetches, uses concurrent requests, and has a bounded expansion-time budget
- sitemap language selection is automatic: the extension detects the current page/site language from rendered page metadata (`html lang`, Content-Language, `og:locale`) and uses a conservative text heuristic only if metadata is absent
- language-specific sitemap variants are prioritized as **autodetected language → English fallback**; unmarked/default sitemaps remain eligible as language-neutral because they often contain the primary sitemap index or site-default content
- explicit sitemap variants for languages outside the detected language and English fallback are discovered but skipped from child fetching/sample-pool construction
- remaining final sample slots favor sitemap sources not already represented, improving cross-sitemap coverage without replacing front-page, current-page, section/detail, or interaction-risk sampling

All discovered sitemap URLs are shown in the popup.

## Browser tests on preflight-approved samples

Every selected sample first receives a non-browser HTML safety preflight. Preflight-approved samples, including the current URL when safe, are opened in disposable tabs inside a **fresh minimized, unfocused Incognito Chrome test window**. Unsafe/non-HTML samples are never browser-navigated. The user's active tab and normal tab strip are not modified or cluttered. The entire isolated window is removed when browser testing finishes, fails, reaches a decisive early exit, or hits a security stop.

The extension deliberately keeps real top-level browser tabs rather than replacing them with an offscreen document, because scrolling, client-side routing, iframe behavior, network requests, and streaming-media tests need a realistic page context.

### Full scrolling

The test scrolls progressively from the top through the current document. At the bottom it waits for appended content and continues through the new material. It stops when the bottom is stable twice or at the safety caps: 10 seconds, 50 scroll steps, or 8 additional bottom-load batches.

A `MutationObserver` and browser resource timing are used to measure new DOM elements, links, text, XHR/fetch/API activity, and repeated infinite-scroll loading. Scroll-triggered XHR/fetch that inserts meaningful crawl-relevant content is decisive high-fidelity evidence.

### Controlled interaction testing

The extension tests at most one safe representative from each family:

- load more
- non-link pagination
- tabs
- accordions/disclosures
- menus/dropdowns

Normal `<a href="...">` navigation is explicitly excluded and never counts as high-fidelity evidence, including href links intercepted by SPA routers.

Potentially destructive or state-changing controls such as login/logout, submit, purchase, delete, consent, download, follow, like, and similar actions are avoided.

A non-navigation interaction is a strong Browsertrix signal when it measurably triggers non-tracking fetch/XHR/API loading and adds crawl-relevant DOM content. Load-more or pagination with this behavior is decisive evidence.

## Streaming media detection

A plain `<video>`/`<audio>` element or a direct MP4/MP3 URL is **not** enough.

The extension looks for actual streaming behavior, including HLS/DASH manifests and repeated media-segment requests. In the disposable tab inside the minimized test window it can briefly mute media, attempt playback, observe resulting network activity, and stop playback again.

Strong Browsertrix signals include:

- the browser/player executes JavaScript and discovers an HLS/DASH manifest that is not exposed in the raw HTML
- streaming media segments begin only after playback starts
- video or audio is fetched continuously as multiple streaming segments

When streaming media is detected, the popup shows this red warning exactly:

> Streaming media detected; crawler capture may be incomplete.

## SPA/client-side routing warning

The extension detects observed History API routing and strong structural router signals such as Next.js, Nuxt, and Angular routing.

When SPA/client-side routing is detected and Browsertrix is recommended, a red warning is shown:

> Client-side routing / SPA detected. Note: possible need for ArchiveWeb.page or custom behavior.

Both warnings can be shown at the same time.

## Gemini Nano

Gemini Nano receives only compact technical measurements. The AI policy explicitly treats scroll-dependent content, interaction-dependent loading, browser-only challenges, and streaming-manifest/segment behavior as high-fidelity evidence while rejecting framework presence, analytics requests, service workers, ordinary lazy loading, and cosmetic rendering differences as sufficient evidence on their own.

## UI

The extension UI is English.

- Gray icon: not analyzed
- Orange icon + percentage badge: analysis running
- Green `H`: Heritrix selected
- Green `B`: Browsertrix selected
- Red `!`: analysis error

The popup includes the recommendation, confidence/scores, current status and progress, a report limited to 10 lines, warnings, discovered sitemap URLs, and sampled page roles.

## Install

1. Unzip the package.
2. Open `chrome://extensions`.
3. Enable **Developer mode**.
4. Choose **Load unpacked**.
5. Select the `crawler-choice-extension` folder.
6. On the extension details page, enable **Allow in Incognito**.
7. Make sure no other Incognito windows are open, then open a website and click **Analyze**.


## v0.8: interactive document/page-flipper detection

The browser test now includes a dedicated page-flipper/document-viewer probe in every accessible frame, including cross-origin iframes covered by the extension host permissions. It looks for non-href Next/forward controls in catalogues, publications, PDF/document viewers, flipbooks and large viewer overlays.

A click is treated as decisive high-fidelity evidence when it advances the viewer by dynamically requesting a new page/image/tile/document resource, changes image sources, changes an observable canvas, or changes viewer route/state. This intentionally does **not** require XHR/fetch: many digital catalogue viewers load the next page as ordinary image resources and reuse existing DOM nodes. Normal `<a href>` navigation remains excluded.

The structural sampler also reserves one slot for a high-fidelity-risk content type when such URLs are discovered in sitemaps or rendered front-page links (for example catalogue/publication/viewer/live/video paths). The URL pattern is **not** itself evidence for Browsertrix; it only ensures that these minority sections are actually browser-tested.


## v1.1: evidence model, guide, sample URLs and early exit

- The popup now lists every selected sample URL with its role.
- A **Guide** button opens an English in-extension guide explaining the goal, decision rule, sitemap sampling, pre-render indicators, raw-vs-rendered comparisons, active probes, warnings and early exit.
- Raw HTML analysis now builds an approximate static-discoverability URL set from common HTML attributes, srcset, CSS URLs and selected URL-like JS/JSON strings. Browser runtime requests are compared against this set.
- A raw application shell that becomes substantial visible content alongside runtime-only API activity is a strong Browsertrix signal; it is not used for early exit by itself.
- Open Shadow DOM links/content and multiple runtime-only crawl-relevant resources are additional strong signals.
- Repeated polling is filtered for common analytics/advertising/tracking patterns and only counts when it resembles content/API traffic and meaningful crawl-relevant DOM changes are also observed.
- **Early exit:** sitemap discovery, sampling and raw HTTP tests always run. During browser testing, a decisive Browsertrix signal stops remaining sample tests, closes the isolated test window and skips Gemini Nano.


## v1.1 security changes

- Browser tests require Chrome **Allow in Incognito** access and use a fresh minimized Incognito window.
- Existing Incognito windows must be closed before analysis so the test cannot share their cookies/session.
- Raw HTTP/sitemap fetches omit credentials.
- Browser samples require an HTML-only preflight; document/archive/media/executable/file-like URLs and attachment/non-HTML responses are never browser-navigated.
- Downloads are monitored with `chrome.downloads`; a test-originated download is cancelled immediately and stops browser testing.
- Popups/new tabs and unsafe top-level navigation from test tabs trigger a security stop.
- Controlled clicks temporarily block form submission, popups, beacons and mutating fetch/XHR methods; GET/HEAD and read-only GraphQL queries remain available.
- The sample count is configurable from 5 to 20.


## v1.1 sample-security semantics

A valid HTML content page is no longer marked `aborted/error` merely because advertising, consent code, an embed, or an active probe attempts a side effect. Popups/new tabs are closed, downloads are cancelled, and unsafe top-level navigation is contained per disposable sample tab. The sample is retained as `browser-tested · safeguards-blocked` when the page test completed, or `browser-test-limited` when a safeguard prevented completion. Other samples continue normally. Non-HTML/file samples remain listed but are never browser-navigated.
