chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== 'offscreen' || msg.type !== 'AI_CLASSIFY') return;
  classify(msg.payload).then(sendResponse).catch(err => sendResponse({ status: 'error', error: String(err?.message || err) }));
  return true;
});

async function classify(payload) {
  if (typeof LanguageModel === 'undefined') {
    return { status: 'unavailable', availability: 'LanguageModel API missing' };
  }

  const options = {
    expectedInputs: [{ type: 'text', languages: ['en'] }],
    expectedOutputs: [{ type: 'text', languages: ['en'] }],
  };

  const availability = await LanguageModel.availability(options);
  if (availability !== 'available') {
    return { status: availability, availability };
  }

  const session = await LanguageModel.create({
    ...options,
    initialPrompts: [{
      role: 'system',
      content: `You classify websites for web archiving. Decide whether a browser-based high-fidelity crawler is technically necessary. Be conservative: choose high fidelity only when measurable evidence shows that important crawl-relevant content, URL discovery, or streaming-media retrieval depends on client-side execution or interaction. Strong evidence includes scroll/network loading that inserts meaningful DOM content; controlled load-more/pagination/tab/accordion/menu interactions without normal href navigation that trigger data loading; interactive document/page-flipper Next controls that load new page/image/tile resources or change viewer canvas/state, including inside embedded frames; browser-only access through a bot/WAF challenge; JavaScript-dependent discovery of an HLS/DASH manifest; media segments requested only after playback starts; or continuously fetched streaming video/audio segments. A plain video/audio element or a direct MP4/MP3 URL alone is NOT sufficient. An ordinary <a href> navigation is NEVER high-fidelity evidence. A JavaScript framework, service worker, analytics requests, ordinary lazy loading with valid href/src, or cosmetic rendering differences are NOT sufficient. If evidence is ambiguous, choose false (Heritrix).`
    }]
  });

  const schema = {
    type: 'object',
    properties: {
      needsHighFidelity: { type: 'boolean' },
      confidence: { type: 'string', enum: ['low','moderate','high'] },
      reasonCodes: {
        type: 'array',
        maxItems: 5,
        items: {
          type: 'string',
          enum: [
            'JS_GENERATED_LINKS','SCROLL_XHR_CONTENT','CLIENT_RENDERED_CONTENT',
            'INTERACTION_ONLY_DISCOVERY','CLICK_DATA_LOADING','INTERACTIVE_PAGE_FLIPPER','IFRAME_DEPENDENCY','BROWSER_BYPASSES_CHALLENGE','STATIC_HTML_SUFFICIENT',
            'SITEMAP_DISCOVERY_SUFFICIENT','FRAMEWORK_ONLY_NOT_ENOUGH','PLAYER_JS_DISCOVERS_MANIFEST','PLAYBACK_STARTS_MEDIA_SEGMENTS','CONTINUOUS_STREAMING_MEDIA','UNCERTAIN'
          ]
        }
      }
    },
    required: ['needsHighFidelity','confidence','reasonCodes'],
    additionalProperties: false
  };

  try {
    const prompt = `Evaluate this compact technical evidence. Do not infer facts not present. Return only the constrained JSON result.\n\n${JSON.stringify(payload)}`;
    const result = await session.prompt(prompt, { responseConstraint: schema });
    const parsed = JSON.parse(result);
    return { status: 'ok', availability, ...parsed };
  } finally {
    session.destroy?.();
  }
}
