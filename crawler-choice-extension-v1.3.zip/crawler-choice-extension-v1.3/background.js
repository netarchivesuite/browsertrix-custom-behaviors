const CONFIG = {
  MAX_SITEMAP_DOCS: 48,
  SITEMAP_POOL_URLS_PER_DOC: 10,
  MAX_SITEMAP_CHILD_FETCHES: 40,
  SITEMAP_CHILD_CONCURRENCY: 10,
  SITEMAP_CHILD_TIMEOUT_MS: 5000,
  SITEMAP_EXPANSION_BUDGET_MS: 12000,
  MAX_SITEMAP_LOCATIONS: 15000,
  MAX_SITEMAP_URLS: 15000,
  MAX_SAMPLES: 20,
  MAX_RENDER_SAMPLES: 20,
  DEFAULT_SAMPLES: 7,
  RENDER_CONCURRENCY: 3,
  FETCH_TIMEOUT_MS: 8000,
  TAB_TIMEOUT_MS: 15000,
  SCROLL_MAX_MS: 10000,
  SCROLL_MAX_STEPS: 50,
  SCROLL_STABLE_BOTTOM_ROUNDS: 2,
  SCROLL_MAX_BOTTOM_LOADS: 8,
  CLICK_TEST_MAX_CANDIDATES: 5,
  CLICK_TEST_SETTLE_MS: 1200,
  MEDIA_PLAYBACK_TEST_MS: 2200,
  MEDIA_MAX_ELEMENTS: 2,
  VIEWER_CLICK_SETTLE_MS: 1800,
  VIEWER_MAX_FRAME_PROBES: 12,
  MAX_HTML_BYTES: 2_500_000,
  MAX_SITEMAP_BYTES: 12_000_000,
  EARLY_EXIT_ON_DECISIVE: true,
  MAX_STATIC_URLS: 5000,
  MAX_RUNTIME_RESOURCE_URLS: 1500,
};

const ICONS = {
  idle: iconSet('idle'),
  running: iconSet('running'),
  heritrix: iconSet('heritrix'),
  browsertrix: iconSet('browsertrix'),
  error: iconSet('error'),
};

function iconSet(name) {
  return {
    16: `icons/${name}16.png`,
    32: `icons/${name}32.png`,
    48: `icons/${name}48.png`,
    128: `icons/${name}128.png`,
  };
}

const COMMON_MULTI_SUFFIXES = new Set([
  'co.uk','org.uk','gov.uk','ac.uk','com.au','net.au','org.au','co.nz','com.br','com.mx',
  'co.jp','co.kr','co.in','com.sg','com.tr','com.cn','com.tw','com.hk','co.za','com.ar'
]);

const BAD_SAMPLE_SEGMENTS = new Set([
  'wp-content','wp-admin','wp-includes','feed','feeds','tag','tags','author','authors','login',
  'logout','account','privacy','cookie','cookies','terms','legal','assets','asset','static','media',
  'images','image','img','files','file','download','downloads','api','ajax','graphql','page','pages'
]);

const SPECIAL_SEGMENTS = new Set([
  'kontakt','contact','om','about','search','soeg','søg','nyheder','news','sport','politik','culture',
  'kultur','business','erhverv','events','begivenheder','products','produkter','services','service'
]);

const HIGH_FIDELITY_RISK_SEGMENTS = new Set([
  'katalog','kataloger','catalog','catalogue','catalogues','tilbudsavis','tilbudsaviser',
  'publication','publications','publikation','publikationer','viewer','reader','flipbook','magazine',
  'leaflet','live','liveblog','player','video','videos','stream','streaming'
]);

let running = new Map();
let offscreenCreating = null;
let activeTestSession = null;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'START_ANALYSIS') {
    const { tabId, url } = msg;
    if (!tabId || !/^https?:/i.test(url || '')) {
      sendResponse({ ok: false, error: 'Only HTTP(S) pages can be analyzed.' });
      return;
    }
    if (isUnsafeBrowserSampleUrl(url)) {
      sendResponse({ ok: false, error: 'This URL looks like a downloadable document/file rather than an HTML page and will not be browser-tested.' });
      return;
    }
    chrome.extension.isAllowedIncognitoAccess().then(allowed => {
      if (!allowed) {
        sendResponse({ ok: false, error: 'Incognito access is required for secure browser tests. Enable “Allow in Incognito” for this extension in chrome://extensions.' });
        return;
      }
      const sampleCount = clampSampleCount(msg.sampleCount);
      if (!running.has(tabId)) {
        const job = runAnalysis(tabId, url, sampleCount)
          .catch(err => failAnalysis(tabId, err))
          .finally(() => running.delete(tabId));
        running.set(tabId, job);
      }
      sendResponse({ ok: true, sampleCount });
    }).catch(err => sendResponse({ ok: false, error: String(err?.message || err) }));
    return true;
  }

  if (msg.type === 'GET_STATE') {
    getState(msg.tabId).then(state => sendResponse({ ok: true, state }));
    return true;
  }

  if (msg.type === 'AI_RESULT' && msg.target === 'service-worker') {
    return;
  }
});

chrome.tabs.onRemoved.addListener(tabId => {
  chrome.storage.local.remove(stateKey(tabId)).catch(() => {});
});

function getTabSecurityState(session, tabId) {
  if (!session?.tabSecurity) return null;
  if (!session.tabSecurity.has(tabId)) session.tabSecurity.set(tabId, { currentUrl: '', events: [] });
  return session.tabSecurity.get(tabId);
}

function recordTabSecurityEvent(session, tabId, type, detail = '') {
  if (!session) return;
  const event = { type, detail, at: Date.now() };
  if (tabId != null) {
    const state = getTabSecurityState(session, tabId);
    if (state) state.events.push(event);
  }
  session.securityEvents ||= [];
  session.securityEvents.push({ tabId: tabId ?? null, ...event });
}

function securityEventsForTab(session, tabId) {
  return [...(session?.tabSecurity?.get(tabId)?.events || [])];
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  const session = activeTestSession;
  if (session?.tabIds?.has(tabId)) {
    const state = getTabSecurityState(session, tabId);
    if (changeInfo.url) state.currentUrl = changeInfo.url;
    if (changeInfo.url && changeInfo.url !== 'about:blank') {
      const u = changeInfo.url;
      if (!/^https?:/i.test(u) || !sameRegisteredDomain(u, session.rootDomain) || isUnsafeBrowserSampleUrl(u)) {
        // Contain the unsafe navigation to this disposable sample tab. Do NOT abort the
        // whole analysis: the page/sample may still be important archival content.
        recordTabSecurityEvent(session, tabId, 'top-navigation-blocked', u);
        chrome.tabs.update(tabId, { url: 'about:blank' }).catch(() => {});
      }
    }
    return;
  }
  if (changeInfo.url && !running.has(tabId)) {
    chrome.storage.local.remove(stateKey(tabId)).catch(() => {});
    setVisualState(tabId, 'idle', '').catch(() => {});
  }
});

chrome.downloads.onCreated.addListener(item => {
  const session = activeTestSession;
  if (!session || !item?.incognito) return;
  const related = [item.url, item.finalUrl, item.referrer].filter(Boolean)
    .some(u => sameRegisteredDomain(u, session.rootDomain));
  if (!related) return;

  // Emergency brake only. Browser samples themselves are preflighted before navigation;
  // this catches a download unexpectedly triggered by page script or a controlled probe.
  chrome.downloads.cancel(item.id).catch(() => {});

  let relatedTabId = null;
  const ref = item.referrer || '';
  if (ref && session.tabSecurity) {
    for (const [tabId, state] of session.tabSecurity.entries()) {
      if (state.currentUrl && (sameUrl(state.currentUrl, ref) || sameUrl(stripHashSafe(state.currentUrl), stripHashSafe(ref)))) {
        relatedTabId = tabId;
        break;
      }
    }
  }
  recordTabSecurityEvent(session, relatedTabId, 'download-blocked', item.finalUrl || item.url || 'unknown URL');
  session.blockedDownload = { id: item.id, url: item.finalUrl || item.url || '', referrer: item.referrer || '' };

  setTimeout(async () => {
    try {
      const found = await chrome.downloads.search({ id: item.id });
      const d = found?.[0];
      if (d?.state === 'complete' && d?.exists) await chrome.downloads.removeFile(item.id).catch(() => {});
      await chrome.downloads.erase({ id: item.id }).catch(() => {});
    } catch {}
  }, 150);
});

chrome.tabs.onCreated.addListener(tab => {
  const session = activeTestSession;
  if (!session || !tab?.incognito || !tab.openerTabId || !session.tabIds.has(tab.openerTabId)) return;
  // Popups/new tabs are contained locally. They are a side effect, not evidence that the
  // source sample itself is invalid or unimportant.
  recordTabSecurityEvent(session, tab.openerTabId, 'popup-blocked', tab.pendingUrl || tab.url || 'popup/new tab');
  chrome.tabs.remove(tab.id).catch(() => {});
});

function triggerSecurityAbort(session, reason) {
  // Reserved for future failures that cannot be safely contained per sample. Ordinary
  // popup/download/navigation side effects no longer call this function.
  if (!session || session.securityAbort) return;
  session.securityAbort = { reason, at: Date.now() };
  if (session.windowId != null) chrome.windows.remove(session.windowId).catch(() => {});
  if (session.rootTabId) progress(session.rootTabId, 70, 'Security stop', reason).catch(() => {});
}

function stripHashSafe(value) {
  try { const u = new URL(value); u.hash = ''; return u.href; } catch { return value || ''; }
}

function clampSampleCount(value) {
  const n = Math.round(Number(value));
  return Number.isFinite(n) ? Math.max(5, Math.min(20, n)) : CONFIG.DEFAULT_SAMPLES;
}

async function runAnalysis(rootTabId, originalUrl, requestedSampleCount = CONFIG.DEFAULT_SAMPLES) {
  const sampleCount = clampSampleCount(requestedSampleCount);
  const startedAt = Date.now();
  await setVisualState(rootTabId, 'running', '0');
  await updateState(rootTabId, {
    running: true,
    done: false,
    progress: 1,
    phase: 'Starting analysis',
    detail: 'Preparing page and domain checks…',
    decision: null,
    report: [],
    sitemapUrls: [],
    samples: [],
    scores: null,
    earlyExit: null,
    warnings: [],
    ai: { status: 'pending' },
    startedAt,
    url: originalUrl,
    sampleLimit: sampleCount,
  });

  const currentTab = await chrome.tabs.get(rootTabId);
  const currentUrl = currentTab.url || originalUrl;
  const rootDomain = registrableDomain(new URL(currentUrl).hostname);

  await progress(rootTabId, 5, 'Analyzing the current page', 'Measuring rendered DOM, links, scripts, media, and browser network activity.');
  const currentRendered = await probeTab(rootTabId, false).catch(() => null);
  const currentLinks = currentRendered?.after?.links || [];
  const languageProfile = detectSiteLanguage(currentRendered?.after || null);

  await updateState(rootTabId, {
    detectedLanguage: languageProfile.detected,
    sitemapLanguagePriority: languageProfile.priorityLabel,
    languageDetectionSource: languageProfile.source,
  });

  await progress(rootTabId, 12, 'Discovering sitemap structure', 'Fetching robots.txt and common sitemap locations in parallel.');
  const sitemap = await discoverSitemaps(currentUrl, rootDomain, sampleCount, languageProfile, (done, total) => {
    const pct = 12 + Math.min(13, Math.round((done / Math.max(total, 1)) * 13));
    progress(rootTabId, pct, 'Discovering sitemap structure', `${done}/${total} sitemap candidates checked.`).catch(() => {});
  });

  await progress(rootTabId, 28, 'Selecting representative samples', 'Prioritizing the front page, distinct sections, and detail/article pages — never random samples.');
  const samples = chooseSamples({
    entries: sitemap.entries,
    sitemapPools: sitemap.pools,
    currentUrl,
    renderedLinks: currentLinks,
    rootDomain,
    max: sampleCount,
  });

  await updateState(rootTabId, {
    sitemapCount: sitemap.entries.length,
    sitemapDocs: sitemap.documents.length,
    sitemapUrls: sitemap.locations,
    samples: samples.map(s => ({ url: s.url, role: s.role })),
  });

  await progress(rootTabId, 34, 'Fetching raw HTML samples', `Fetching ${samples.length} samples in parallel without browser rendering.`);
  let rawDone = 0;
  const rawResults = await Promise.all(samples.map(async sample => {
    const res = await fetchPage(sample.url).catch(err => ({ ok: false, url: sample.url, error: String(err) }));
    rawDone++;
    const pct = 34 + Math.round((rawDone / Math.max(samples.length, 1)) * 16);
    progress(rootTabId, pct, 'Fetching raw HTML samples', `${rawDone}/${samples.length} fetched.`).catch(() => {});
    const browserSafety = assessBrowserSampleSafety(sample.url, res, rootDomain);
    const raw = res?.text && browserSafety.htmlLike ? analyzeRawHtml(res.text, res.finalUrl || sample.url, rootDomain) : null;
    return { sample, fetch: res, raw, browserSafety };
  }));

  const rawByUrlForSafety = new Map(rawResults.map(r => [canonicalKey(r.sample.url), r]));
  const allRenderTargets = selectRenderTargets(samples, currentUrl, Math.min(sampleCount, CONFIG.MAX_RENDER_SAMPLES));
  const renderTargets = allRenderTargets.filter(sample => rawByUrlForSafety.get(canonicalKey(sample.url))?.browserSafety?.safe);
  const unsafeRenderTargets = allRenderTargets.filter(sample => !rawByUrlForSafety.get(canonicalKey(sample.url))?.browserSafety?.safe);
  if (allRenderTargets.length && renderTargets.length === 0) {
    throw new Error('Security preflight could not confirm any selected sample as a renderable HTML page. Browser testing was not started.');
  }
  await progress(rootTabId, 52, 'Preparing secure browser tests', `Preparing ${renderTargets.length}/${allRenderTargets.length} preflight-approved HTML samples in a fresh minimized Incognito window. ${unsafeRenderTargets.length} unsafe/non-HTML sample(s) will not be browser-navigated.`);

  let renderDone = 0;
  let renderedResults = [];
  let testWindowId = null;
  let earlyExit = null;
  try {
    const testSession = await createIsolatedTestWindow(rootTabId, rootDomain);
    testWindowId = testSession.windowId;
    await progress(rootTabId, 53, 'Rendering, scrolling, and interaction-testing samples', `Testing up to ${renderTargets.length} preflight-approved HTML samples in a fresh minimized Incognito window: full scrolling, security-filtered interaction checks, embedded page-flipper probing, streaming-media probing, runtime-only resource comparison, and content-polling checks; up to ${CONFIG.RENDER_CONCURRENCY} concurrently.`);

    const rawByUrl = new Map(rawResults.map(r => [canonicalKey(r.sample.url), r]));
    const scheduled = await mapLimitUntil(renderTargets, CONFIG.RENDER_CONCURRENCY, async sample => {
      const result = await renderInBackgroundTab(sample.url, rootDomain, testWindowId).catch(err => ({ error: String(err) }));
      renderDone++;
      const item = { sample, rendered: result };
      const decisive = CONFIG.EARLY_EXIT_ON_DECISIVE
        ? detectDecisiveBrowsertrixSample(rawByUrl.get(canonicalKey(sample.url)), result)
        : null;
      const pct = 53 + Math.round((renderDone / Math.max(renderTargets.length, 1)) * 24);

      if (decisive && !earlyExit) {
        earlyExit = { ...decisive, sampleUrl: sample.url, sampleRole: sample.role, testedSamples: renderDone };
        await progress(rootTabId, Math.max(70, pct), 'Decisive Browsertrix evidence found', `${decisive.text} Remaining browser samples are being stopped.`);
        // Removing the isolated window aborts any already-running sibling sample tabs.
        // mapLimitUntil also prevents new samples from being scheduled.
        if (testWindowId != null) await chrome.windows.remove(testWindowId).catch(() => {});
        return { value: item, stop: true };
      }
      // Another concurrent worker may finish only because its tab was destroyed by the
      // early-exit window close. Do not overwrite the decisive status message.
      if (earlyExit) return { value: item, stop: true };

      await progress(rootTabId, pct, 'Rendering, scrolling, and interaction-testing samples', `${renderDone}/${renderTargets.length} complete: ${shortUrl(sample.url)}`);
      return { value: item, stop: false };
    });
    renderedResults = scheduled.results.filter(Boolean);
    if (activeTestSession?.securityAbort) {
      throw new Error(`Security stop: ${activeTestSession.securityAbort.reason}`);
    }
  } finally {
    if (testWindowId != null) {
      await chrome.windows.remove(testWindowId).catch(() => {});
    }
    if (activeTestSession?.windowId === testWindowId) activeTestSession = null;
  }

  await progress(rootTabId, 79, 'Comparing HTTP and browser results', earlyExit
    ? 'A decisive high-fidelity signal ended browser testing early; scoring the evidence already collected.'
    : 'Comparing raw HTML with rendered DOM, runtime-only resources, scrolling, controlled clicks, content polling, embedded page-flippers, media streaming, XHR/fetch, Shadow DOM, and client-side routing.');
  const combined = combineResults(rawResults, renderedResults);
  const scored = scoreEvidence(combined, sitemap, samples);

  let ai;
  if (earlyExit) {
    ai = { status: 'skipped-decisive', needsHighFidelity: true, confidence: 'high', reason: 'Gemini Nano was skipped because decisive measured Browsertrix evidence had already been found.' };
    await progress(rootTabId, 92, 'Skipping Gemini Nano', 'Measured evidence is already decisive; no AI second opinion is needed.');
  } else {
    await progress(rootTabId, 88, 'Gemini Nano is evaluating evidence', 'AI receives only compact technical measurements and must classify conservatively.');
    ai = await classifyWithNano(scored.aiPayload).catch(err => ({ status: 'error', error: String(err) }));
  }

  await progress(rootTabId, 96, 'Applying decision rule', 'Browsertrix is selected only when the need for high-fidelity crawling is supported with high confidence; otherwise Heritrix.');
  const final = makeDecision(scored, ai);
  const report = buildReport(final, scored, ai, sitemap, samples, earlyExit, languageProfile).slice(0, 10);
  const renderedStatus = new Map(renderedResults.map(r => {
    const rr = r.rendered || {};
    let status = 'browser-tested';
    if (rr.securityLimited || rr.testLimited) status = 'browser-test-limited';
    else if (rr.error) status = 'browser-test-failed';
    else if (rr.safeguardsTriggered) status = 'browser-tested · safeguards-blocked';
    return [canonicalKey(r.sample.url), status];
  }));
  const safetyMap = new Map(rawResults.map(r => [canonicalKey(r.sample.url), r.browserSafety]));
  const finalSamples = samples.map(sample => {
    const safety = safetyMap.get(canonicalKey(sample.url));
    let status = renderedStatus.get(canonicalKey(sample.url));
    if (!status && safety && !safety.safe) status = `not-browser-tested:${safety.reason}`;
    if (!status) status = earlyExit ? 'skipped-after-early-exit' : 'not-browser-tested';
    return { url: sample.url, role: sample.role, status };
  });

  await updateState(rootTabId, {
    running: false,
    done: true,
    progress: 100,
    phase: 'Analysis complete',
    detail: earlyExit
      ? `${final.decision} selected after decisive evidence on ${shortUrl(earlyExit.sampleUrl)}. ${earlyExit.testedSamples}/${renderTargets.length} browser samples were started/completed before early exit.`
      : `${final.decision} selected. ${samples.length} samples, ${sitemap.locations.length} sitemap locations, ${sitemap.pools?.length || 0} sitemap candidate pools, and ${sitemap.entries.length} content URLs discovered from sitemaps.`,
    decision: final.decision,
    report,
    detectedLanguage: languageProfile.detected,
    sitemapLanguagePriority: languageProfile.priorityLabel,
    languageDetectionSource: languageProfile.source,
    samples: finalSamples,
    ai,
    scores: {
      browsertrix: scored.browsertrixScore,
      heritrix: scored.heritrixScore,
      strongSignals: scored.strongCount,
      highFidelityConfidence: final.confidence,
    },
    earlyExit,
    warnings: [
      ...(final.decision === 'Browsertrix' && scored.spaDetected
        ? ['Client-side routing / SPA detected. Note: possible need for ArchiveWeb.page or custom behavior.']
        : []),
      ...(scored.streamingDetected
        ? ['Streaming media detected; crawler capture may be incomplete.']
        : []),
    ],
    finishedAt: Date.now(),
  });

  await setVisualState(rootTabId, final.decision === 'Browsertrix' ? 'browsertrix' : 'heritrix', final.decision === 'Browsertrix' ? 'B' : 'H');
}

async function failAnalysis(tabId, err) {
  console.error(err);
  await updateState(tabId, {
    running: false,
    done: true,
    progress: 100,
    phase: 'Analysis failed',
    detail: String(err?.message || err),
    decision: null,
    report: ['The analysis could not be completed.', String(err?.message || err).slice(0, 220)],
  }).catch(() => {});
  await setVisualState(tabId, 'error', '!').catch(() => {});
}

async function setVisualState(tabId, state, badgeText = '') {
  await Promise.all([
    chrome.action.setIcon({ tabId, path: ICONS[state] }),
    chrome.action.setBadgeText({ tabId, text: String(badgeText).slice(0, 4) }),
    chrome.action.setBadgeBackgroundColor({ tabId, color: state === 'running' ? '#F59E0B' : state === 'error' ? '#DC2626' : state === 'idle' ? '#6B7280' : '#16A34A' }),
  ]);
}

async function progress(tabId, percent, phase, detail) {
  await updateState(tabId, { progress: percent, phase, detail });
  await chrome.action.setBadgeText({ tabId, text: percent >= 100 ? '' : String(Math.max(0, Math.min(99, Math.round(percent)))) });
}

function stateKey(tabId) { return `analysis:${tabId}`; }
async function getState(tabId) {
  if (!tabId) return null;
  const obj = await chrome.storage.local.get(stateKey(tabId));
  return obj[stateKey(tabId)] || null;
}
async function updateState(tabId, patch) {
  const current = await getState(tabId) || {};
  const next = { ...current, ...patch, tabId };
  await chrome.storage.local.set({ [stateKey(tabId)]: next });
  chrome.runtime.sendMessage({ type: 'STATE_UPDATED', tabId, state: next }).catch(() => {});
  return next;
}

function registrableDomain(hostname) {
  const host = (hostname || '').toLowerCase().replace(/\.$/, '');
  if (!host || /^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(':')) return host;
  const p = host.split('.').filter(Boolean);
  if (p.length <= 2) return host;
  const last2 = p.slice(-2).join('.');
  if (COMMON_MULTI_SUFFIXES.has(last2) && p.length >= 3) return p.slice(-3).join('.');
  return last2;
}

function sameRegisteredDomain(url, rootDomain) {
  try { return registrableDomain(new URL(url).hostname) === rootDomain; } catch { return false; }
}

function sameUrl(a, b) {
  try {
    const ua = new URL(a), ub = new URL(b);
    ua.hash = ''; ub.hash = '';
    return ua.href === ub.href;
  } catch { return a === b; }
}

function shortUrl(url) {
  try {
    const u = new URL(url);
    const s = `${u.hostname}${u.pathname}${u.search}`;
    return s.length > 72 ? `${s.slice(0, 34)}…${s.slice(-34)}` : s;
  } catch { return String(url).slice(0, 72); }
}

async function discoverSitemaps(pageUrl, rootDomain, sampleCount, languageProfile, onProgress) {
  const origin = new URL(pageUrl).origin;
  const startedAt = Date.now();
  const expansionDeadline = startedAt + CONFIG.SITEMAP_EXPANSION_BUDGET_MS;
  const maxChildFetches = Math.min(CONFIG.MAX_SITEMAP_CHILD_FETCHES, Math.max(12, clampSampleCount(sampleCount) * 2));

  // Mirrors the broader discovery strategy from the standalone sitemap finder:
  // robots.txt first-class discovery + common XML/TXT/gzip/index variants.
  // Keep both lower/upper-case Sitemap.xml because they are distinct on case-sensitive servers.
  const defaults = [
    `${origin}/sitemap.xml`,
    `${origin}/Sitemap.xml`,
    `${origin}/sitemap_index.xml`,
    `${origin}/sitemap-index.xml`,
    `${origin}/wp-sitemap.xml`,
    `${origin}/sitemaps.xml`,
    `${origin}/sitemap.txt`,
    `${origin}/sitemap/sitemap.xml`,
    `${origin}/sitemap/sitemap_index.xml`,
    `${origin}/sitemap/sitemap-index.xml`,
    `${origin}/sitemap.xml.gz`,
    `${origin}/sitemap_index.xml.gz`,
    `${origin}/sitemap-index.xml.gz`,
    `${origin}/sitemap/sitemap.xml.gz`,
  ];

  // Robots and common probes happen concurrently for speed.
  const robotsPromise = fetchText(`${origin}/robots.txt`, 1_000_000).catch(() => null);
  const initialPromise = Promise.all(defaults.map(url => fetchSitemapDoc(url).catch(() => null)));
  const [robots, defaultDocs] = await Promise.all([robotsPromise, initialPromise]);

  const robotsSitemaps = robots?.ok ? parseRobotsSitemaps(robots.text, origin) : [];
  const validByUrl = new Map();
  for (const doc of defaultDocs) {
    if (doc?.valid) validByUrl.set(canonicalKey(doc.finalUrl || doc.url), doc);
  }

  // robots.txt may contain arbitrary paths, query strings, extensionless URLs,
  // cross-host URLs, and more than one Sitemap: declaration. Obvious language
  // variants outside the autodetected site language and English fallback are deliberately
  // not fetched for the sampling pool. Unmarked/default sitemap URLs remain eligible as neutral.
  const robotCandidates = robotsSitemaps
    .filter(u => !defaults.some(d => sameUrl(d, u)))
    .map(url => ({ url, lastmod: '' }));
  const robotsSkippedLanguage = robotCandidates.filter(e => !classifySitemapLanguage(e.url, languageProfile).allowed).length;
  const robotEligible = robotCandidates.filter(e => classifySitemapLanguage(e.url, languageProfile).allowed);
  const maxRobotFetches = Math.min(20, Math.max(8, clampSampleCount(sampleCount)));
  const extra = (robotEligible.length <= maxRobotFetches
    ? robotEligible
    : chooseSitemapChildren(robotEligible, maxRobotFetches, languageProfile)).map(e => e.url);
  const extraDocs = await mapLimit(extra, 8, url => fetchSitemapDoc(url, { timeoutMs: CONFIG.SITEMAP_CHILD_TIMEOUT_MS }).catch(() => null));
  for (const doc of extraDocs) {
    if (doc?.valid) validByUrl.set(canonicalKey(doc.finalUrl || doc.url), doc);
  }

  const seenDocs = new Set();
  const seenContent = new Set();
  const locations = new Map();
  const documents = [];
  const entries = [];
  const pools = new Map();
  let queue = [...validByUrl.values()];
  let processed = 0;
  let childFetches = 0;
  let skippedLanguageSitemaps = robotsSkippedLanguage;

  const rememberLocation = (url, source = '') => {
    try {
      const u = new URL(url);
      u.hash = '';
      const key = u.href;
      if (!locations.has(key) && locations.size < CONFIG.MAX_SITEMAP_LOCATIONS) {
        locations.set(key, { url: key, source });
      }
    } catch {}
  };

  const rememberPool = (docUrl, doc) => {
    const lang = classifySitemapLanguage(docUrl, languageProfile);
    if (!lang.allowed) return;
    const picked = [];
    for (const e of doc.entries || []) {
      if (picked.length >= CONFIG.SITEMAP_POOL_URLS_PER_DOC) break;
      try {
        const u = new URL(e.url, docUrl);
        u.hash = '';
        if (!/^https?:$/.test(u.protocol)) continue;
        if (!sameRegisteredDomain(u.href, rootDomain)) continue;
        if (isUnsafeBrowserSampleUrl(u.href)) continue;
        picked.push({ url: u.href, lastmod: e.lastmod || '', sourceSitemap: docUrl, sitemapLanguage: lang.code || 'default' });
      } catch {}
    }
    if (picked.length) pools.set(docUrl, {
      sitemapUrl: docUrl,
      language: lang.code || 'default',
      languagePriority: lang.priority,
      entries: picked,
    });
  };

  for (const doc of queue) rememberLocation(doc.finalUrl || doc.url, 'validated');

  while (queue.length && documents.length < CONFIG.MAX_SITEMAP_DOCS && entries.length < CONFIG.MAX_SITEMAP_URLS) {
    const doc = queue.shift();
    if (!doc) continue;
    const docUrl = canonicalKey(doc.finalUrl || doc.url);
    if (seenDocs.has(docUrl)) continue;
    seenDocs.add(docUrl);
    rememberLocation(docUrl, 'validated');

    // Equivalent sitemap content served at multiple locations should only be parsed once,
    // but every discovered location remains visible in the UI.
    if (doc.contentKey && seenContent.has(doc.contentKey)) continue;
    if (doc.contentKey) seenContent.add(doc.contentKey);

    documents.push(docUrl);
    processed++;
    onProgress?.(processed, Math.max(processed + queue.length, 1));

    if (doc.type === 'urlset' || doc.type === 'text') {
      rememberPool(docUrl, doc);
      for (const e of doc.entries) {
        if (entries.length >= CONFIG.MAX_SITEMAP_URLS) break;
        if (sameRegisteredDomain(e.url, rootDomain)) entries.push({ ...e, sourceSitemap: docUrl });
      }
      continue;
    }

    if (doc.type === 'index') {
      // Every child referenced by a valid index is still recorded as a discovered sitemap
      // location. Fetching is bounded separately because some sites expose thousands.
      for (const e of doc.entries) rememberLocation(e.url, 'sitemapindex');

      const languageEligible = doc.entries.filter(e => {
        const lang = classifySitemapLanguage(e.url, languageProfile);
        if (!lang.allowed) skippedLanguageSitemaps++;
        return lang.allowed;
      });

      const room = Math.max(0, CONFIG.MAX_SITEMAP_DOCS - documents.length);
      const childRoom = Math.max(0, maxChildFetches - childFetches);
      const withinBudget = Date.now() < expansionDeadline;
      if (!room || !childRoom || !withinBudget) continue;

      // When there are only a few eligible child sitemaps, all of them are included.
      // With huge indexes, choose a deterministic language-prioritized and structurally
      // diverse subset. The cap scales with the user's requested sample count.
      const children = chooseSitemapChildren(languageEligible, Math.min(room, childRoom), languageProfile);
      const unseen = children.filter(e => !seenDocs.has(canonicalKey(e.url)));
      const childDocs = await mapLimit(unseen, CONFIG.SITEMAP_CHILD_CONCURRENCY, async e => {
        if (Date.now() >= expansionDeadline || childFetches >= maxChildFetches) return null;
        childFetches++;
        return fetchSitemapDoc(e.url, { timeoutMs: CONFIG.SITEMAP_CHILD_TIMEOUT_MS }).catch(() => null);
      });
      for (const child of childDocs) {
        if (child?.valid) {
          rememberLocation(child.finalUrl || child.url, 'validated-child');
          queue.push(child);
        }
      }
    }
  }

  const poolList = [...pools.values()].sort((a, b) =>
    a.languagePriority - b.languagePriority || a.sitemapUrl.localeCompare(b.sitemapUrl)
  );

  return {
    entries: dedupeEntries(entries),
    documents,
    locations: [...locations.values()].map(x => x.url),
    robotsSitemaps,
    pools: poolList,
    childFetches,
    maxChildFetches,
    skippedLanguageSitemaps,
    expansionBudgetMs: CONFIG.SITEMAP_EXPANSION_BUDGET_MS,
    languageProfile,
  };
}

function parseRobotsSitemaps(text, base) {
  const out = [];
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*Sitemap\s*:\s*(\S+)/i);
    if (!m) continue;
    try { out.push(new URL(m[1].trim(), base).href); } catch {}
  }
  return [...new Set(out)];
}

async function fetchSitemapDoc(url, options = {}) {
  const res = await fetchText(url, CONFIG.MAX_SITEMAP_BYTES, 'application/xml,text/xml,text/plain,text/html,*/*;q=0.1', options.timeoutMs || CONFIG.FETCH_TIMEOUT_MS);
  if (!res.ok) return null;
  const text = res.text || '';
  let parsed = parseSitemap(text, res.finalUrl || url);
  if (!parsed) parsed = parsePlainTextSitemap(text, res.finalUrl || url, res.contentType || '');
  if (!parsed) return null;
  return {
    ...parsed,
    url,
    finalUrl: res.finalUrl || url,
    valid: true,
    contentKey: sitemapContentKey(text),
  };
}

function parseSitemap(xml, baseUrl) {
  if (!/<(?:\w+:)?(?:urlset|sitemapindex)\b/i.test(xml)) return null;
  const isIndex = /<(?:\w+:)?sitemapindex\b/i.test(xml);
  const tag = isIndex ? 'sitemap' : 'url';
  const re = new RegExp(`<(?:\\w+:)?${tag}\\b[^>]*>([\\s\\S]*?)<\\/(?:\\w+:)?${tag}>`, 'gi');
  const entries = [];
  let m;
  while ((m = re.exec(xml)) && entries.length < CONFIG.MAX_SITEMAP_URLS) {
    const block = m[1];
    const loc = block.match(/<(?:\w+:)?loc\b[^>]*>([\s\S]*?)<\/(?:\w+:)?loc>/i)?.[1];
    if (!loc) continue;
    const lastmod = block.match(/<(?:\w+:)?lastmod\b[^>]*>([\s\S]*?)<\/(?:\w+:)?lastmod>/i)?.[1]?.trim() || '';
    try { entries.push({ url: new URL(xmlUnescape(loc.trim()), baseUrl).href, lastmod }); } catch {}
  }
  // A structurally valid empty <urlset> or <sitemapindex> is deliberately retained.
  return { type: isIndex ? 'index' : 'urlset', entries };
}

function parsePlainTextSitemap(text, baseUrl, contentType) {
  const looksTxt = /\.txt(?:$|[?#])/i.test(baseUrl) || /^text\/plain\b/i.test(contentType || '');
  if (!looksTxt || !text.trim()) return null;
  const entries = [];
  for (const line of text.split(/\r?\n/)) {
    const value = line.trim();
    if (!value || value.startsWith('#')) continue;
    try {
      const u = new URL(value, baseUrl);
      if (!/^https?:$/.test(u.protocol)) return null;
      entries.push({ url: u.href, lastmod: '' });
      if (entries.length >= CONFIG.MAX_SITEMAP_URLS) break;
    } catch { return null; }
  }
  return entries.length ? { type: 'text', entries } : null;
}

function sitemapContentKey(text) {
  // Fast non-cryptographic content signature; enough to avoid parsing duplicate sitemap bodies.
  let h1 = 2166136261 >>> 0;
  let h2 = 2246822519 >>> 0;
  const step = Math.max(1, Math.floor(text.length / 200000));
  for (let i = 0; i < text.length; i += step) {
    const c = text.charCodeAt(i);
    h1 ^= c; h1 = Math.imul(h1, 16777619) >>> 0;
    h2 ^= (c + i) & 0xffff; h2 = Math.imul(h2, 3266489917) >>> 0;
  }
  return `${text.length}:${h1.toString(16)}:${h2.toString(16)}`;
}

function xmlUnescape(s) {
  return s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}

const ISO_639_1_CODES = new Set([
  'aa','ab','ae','af','ak','am','an','ar','as','av','ay','az','ba','be','bg','bh','bi','bm','bn','bo','br','bs','ca','ce','ch','co','cr','cs','cu','cv','cy','da','de','dv','dz','ee','el','en','eo','es','et','eu','fa','ff','fi','fj','fo','fr','fy','ga','gd','gl','gn','gu','gv','ha','he','hi','ho','hr','ht','hu','hy','hz','ia','id','ie','ig','ii','ik','io','is','it','iu','ja','jv','ka','kg','ki','kj','kk','kl','km','kn','ko','kr','ks','ku','kv','kw','ky','la','lb','lg','li','ln','lo','lt','lu','lv','mg','mh','mi','mk','ml','mn','mr','ms','mt','my','na','nb','nd','ne','ng','nl','nn','no','nr','nv','ny','oc','oj','om','or','os','pa','pi','pl','ps','pt','qu','rm','rn','ro','ru','rw','sa','sc','sd','se','sg','si','sk','sl','sm','sn','so','sq','sr','ss','st','su','sv','sw','ta','te','tg','th','ti','tk','tl','tn','to','tr','ts','tt','tw','ty','ug','uk','ur','uz','ve','vi','vo','wa','wo','xh','yi','yo','za','zh','zu'
]);

function normalizeLanguageCode(value) {
  const raw = String(value || '').trim().toLowerCase().replace('_', '-');
  const m = raw.match(/^([a-z]{2})(?:-[a-z]{2,4})?(?:\b|$)/i);
  return m && ISO_639_1_CODES.has(m[1]) ? m[1] : null;
}

function detectSiteLanguage(page) {
  const fallback = 'en';
  const explicit = [
    ['html lang', page?.documentLanguage],
    ['Content-Language meta', page?.metaContentLanguage],
    ['og:locale', page?.ogLocale],
  ];
  for (const [source, value] of explicit) {
    const code = normalizeLanguageCode(value);
    if (code) {
      const priorities = code === fallback ? [code] : [code, fallback];
      return {
        detected: code,
        fallback,
        source: `${source}: ${String(value).trim()}`,
        confidence: 'high',
        priorities,
        priorityLabel: priorities.join(' → '),
      };
    }
  }

  // A language-coded host or first path segment is useful when page metadata is absent.
  try {
    const u = new URL(page?.url || '');
    const hostParts = u.hostname.toLowerCase().split('.').filter(Boolean);
    const hostLead = hostParts[0] === 'www' ? null : hostParts[0];
    const pathLead = decodeURIComponentSafe(u.pathname.split('/').filter(Boolean)[0] || '').toLowerCase();
    const hinted = (hostParts.length >= 3 && ISO_639_1_CODES.has(hostLead))
      ? hostLead
      : normalizeLanguageCode(pathLead);
    if (hinted) {
      const priorities = hinted === fallback ? [hinted] : [hinted, fallback];
      return { detected: hinted, fallback, source: 'language-coded page URL', confidence: 'moderate', priorities, priorityLabel: priorities.join(' → ') };
    }
  } catch {}

  // Lightweight fallback for the two languages most relevant to this installation.
  // It is deliberately conservative and is used only when explicit page metadata is absent.
  const text = ` ${String(page?.textSample || '').toLowerCase().replace(/[^a-zæøå\s]/g, ' ').replace(/\s+/g, ' ')} `;
  const scoreWords = words => words.reduce((n, w) => n + (text.match(new RegExp(`\\b${w}\\b`, 'g')) || []).length, 0);
  const daScore = scoreWords(['og','det','der','som','med','til','af','er','på','ikke','for','fra','har','den','de']) + ((text.match(/[æøå]/g) || []).length * 2);
  const enScore = scoreWords(['the','and','that','with','for','from','this','are','not','have','has','you','your','was','will']);
  if (daScore >= 8 && daScore >= enScore * 1.5) {
    return { detected: 'da', fallback, source: 'rendered text heuristic', confidence: 'moderate', priorities: ['da','en'], priorityLabel: 'da → en' };
  }
  if (enScore >= 8 && enScore >= daScore * 1.5) {
    return { detected: 'en', fallback, source: 'rendered text heuristic', confidence: 'moderate', priorities: ['en'], priorityLabel: 'en' };
  }
  return { detected: fallback, fallback, source: 'English fallback (no reliable page-language signal)', confidence: 'fallback', priorities: [fallback], priorityLabel: fallback };
}

function classifySitemapLanguage(url, languageProfile = { detected: 'en', fallback: 'en', priorities: ['en'] }) {
  try {
    const u = new URL(url);
    const segments = u.pathname.toLowerCase().split('/').filter(Boolean).map(x => decodeURIComponentSafe(x));
    const candidates = [];

    const hostParts = u.hostname.toLowerCase().split('.').filter(Boolean);
    const hostLead = hostParts[0] === 'www' ? hostParts[1] : hostParts[0];
    if (hostParts.length >= 3 && ISO_639_1_CODES.has(hostLead)) candidates.push(hostLead);

    for (const key of ['lang','language','locale','hl']) {
      const value = (u.searchParams.get(key) || '').toLowerCase();
      const m = value.match(/^([a-z]{2})(?:[-_][a-z]{2})?$/);
      if (m && ISO_639_1_CODES.has(m[1])) candidates.push(m[1]);
    }

    for (let i = 0; i < segments.length; i++) {
      const raw = segments[i].replace(/\.(?:xml|txt|gz)$/gi, '');
      const tokens = raw.split(/[^a-z0-9]+/).filter(Boolean);
      if (!tokens.length) continue;
      if (i === 0 && ISO_639_1_CODES.has(tokens[0])) candidates.push(tokens[0]);
      if (ISO_639_1_CODES.has(tokens[0]) && tokens.some(t => t === 'sitemap' || t === 'sitemaps')) candidates.push(tokens[0]);
      for (let t = 0; t < tokens.length; t++) {
        if (!ISO_639_1_CODES.has(tokens[t])) continue;
        const left = tokens[t - 1] || '';
        const right = tokens[t + 1] || '';
        if (left === 'sitemap' || left === 'sitemaps' || right === 'sitemap' || right === 'sitemaps') candidates.push(tokens[t]);
      }
      if (tokens.length === 1 && ISO_639_1_CODES.has(tokens[0])) {
        const next = (segments[i + 1] || '').toLowerCase();
        if (/sitemap/.test(next)) candidates.push(tokens[0]);
      }
    }

    const code = candidates.find(Boolean) || null;
    const priorities = [...new Set((languageProfile.priorities || [languageProfile.detected || 'en', languageProfile.fallback || 'en']).filter(Boolean))];
    if (!code) {
      // Unmarked/default sitemaps are language-neutral and remain eligible. They are
      // placed after the detected-language variant but before the English fallback.
      return { code: null, label: 'default', priority: 1, allowed: true, neutral: true };
    }
    const idx = priorities.indexOf(code);
    if (idx < 0) return { code, label: code, priority: 99, allowed: false, neutral: false };
    // Detected language gets priority 0. English fallback is placed after neutral/default.
    const priority = idx === 0 ? 0 : 2 + idx - 1;
    return { code, label: code, priority, allowed: true, neutral: false };
  } catch {
    return { code: null, label: 'default', priority: 1, allowed: true, neutral: true };
  }
}

function chooseSitemapChildren(entries, limit, languageProfile) {
  const scored = entries.map(e => {
    let group = 'other';
    try {
      const u = new URL(e.url);
      const filename = u.pathname.split('/').pop() || '';
      group = filename
        .replace(/\.(?:xml|txt|gz)$/gi, '')
        .replace(/\b[a-z]{2}(?:[-_][a-z]{2})?\b/gi, '{lang}')
        .replace(/\d{4}[-_]?\d{0,2}[-_]?\d{0,2}/g, '#')
        .replace(/\d+/g, '#')
        .replace(/[-_]+#/g, '#')
        .toLowerCase();
    } catch {}
    const language = classifySitemapLanguage(e.url, languageProfile);
    return { ...e, group, language, ts: Date.parse(e.lastmod || '') || 0 };
  })
    .filter(e => e.language.allowed)
    .sort((a,b) => a.language.priority - b.language.priority || b.ts - a.ts || a.url.localeCompare(b.url));

  const out = [];
  const priorities = [...new Set(scored.map(x => x.language.priority))].sort((a,b) => a-b);
  for (const priority of priorities) {
    const bucket = scored.filter(x => x.language.priority === priority);
    const usedGroups = new Set();
    for (const e of bucket) {
      if (usedGroups.has(e.group)) continue;
      out.push(e);
      usedGroups.add(e.group);
      if (out.length >= limit) return out;
    }
    for (const e of bucket) {
      if (!out.some(x => sameUrl(x.url, e.url))) out.push(e);
      if (out.length >= limit) return out;
    }
  }
  return out;
}

function dedupeEntries(entries) {
  const map = new Map();
  for (const e of entries) {
    try {
      const u = new URL(e.url);
      u.hash = '';
      const key = u.href;
      const prev = map.get(key);
      if (!prev || (Date.parse(e.lastmod || '') || 0) > (Date.parse(prev.lastmod || '') || 0)) map.set(key, { ...e, url: key });
    } catch {}
  }
  return [...map.values()];
}

function chooseSamples({ entries, sitemapPools = [], currentUrl, renderedLinks, rootDomain, max }) {
  const current = new URL(currentUrl);
  const rootUrl = `${current.origin}/`;

  // Each fetched content sitemap contributes a small bounded pool (normally its first
  // 10 suitable page URLs). These are deliberately inserted into the candidate set even
  // when a large earlier sitemap has already filled much of the general entry collection.
  const pooledEntries = sitemapPools.flatMap(pool =>
    (pool.entries || []).map((e, index) => ({
      ...e,
      sourceSitemap: pool.sitemapUrl,
      sitemapLanguage: pool.language,
      sitemapLanguagePriority: pool.languagePriority,
      sitemapPool: true,
      sitemapPoolIndex: index,
    }))
  );
  const source = [
    ...entries,
    ...pooledEntries,
    ...(renderedLinks || []).map(url => ({ url, lastmod: '', sourceSitemap: 'rendered-frontpage' }))
  ];

  const candidateMap = new Map();
  for (const e of source) {
    try {
      const u = new URL(e.url, currentUrl);
      if (!/^https?:$/.test(u.protocol) || registrableDomain(u.hostname) !== rootDomain) continue;
      if (isUnsafeBrowserSampleUrl(u.href)) continue;
      u.hash = '';
      const segs = pathSegments(u);
      if (segs.some(s => BAD_SAMPLE_SEGMENTS.has(s.toLowerCase()))) continue;
      const candidate = { ...e, url: u.href, segs, depth: segs.length, ts: Date.parse(e.lastmod || '') || 0 };
      const prev = candidateMap.get(u.href);
      if (!prev) candidateMap.set(u.href, candidate);
      else {
        // Preserve sitemap-pool provenance when the same URL also occurs in the broader
        // sitemap entry set or in rendered front-page discovery.
        candidateMap.set(u.href, {
          ...prev,
          ...candidate,
          sitemapPool: Boolean(prev.sitemapPool || candidate.sitemapPool),
          sourceSitemap: candidate.sitemapPool ? candidate.sourceSitemap : (prev.sourceSitemap || candidate.sourceSitemap),
          sitemapLanguage: candidate.sitemapPool ? candidate.sitemapLanguage : prev.sitemapLanguage,
          sitemapLanguagePriority: candidate.sitemapPool ? candidate.sitemapLanguagePriority : prev.sitemapLanguagePriority,
          sitemapPoolIndex: candidate.sitemapPool ? candidate.sitemapPoolIndex : prev.sitemapPoolIndex,
          ts: Math.max(prev.ts || 0, candidate.ts || 0),
        });
      }
    } catch {}
  }

  const dedup = [...candidateMap.values()];
  const prefixCounts = new Map();
  for (const c of dedup) {
    const p = c.segs[0]?.toLowerCase();
    if (p) prefixCounts.set(p, (prefixCounts.get(p) || 0) + 1);
  }

  const chosen = [];
  const sampleMeta = (c, extra = {}) => c ? ({
    sourceSitemap: c.sourceSitemap || '',
    sitemapLanguage: c.sitemapLanguage || '',
    sitemapPool: Boolean(c.sitemapPool),
    ...extra,
  }) : extra;
  const add = (url, role, meta = {}) => {
    if (!url || chosen.some(x => sameUrl(x.url, url))) return false;
    chosen.push({ url, role, ...meta });
    return true;
  };

  // Two reserved anchors: front page and the exact page the user is looking at.
  // If they are identical, keep a single sample but mark both roles.
  if (sameUrl(rootUrl, currentUrl)) add(rootUrl, 'front-page+current-page', { current: true });
  else {
    add(rootUrl, 'front-page');
    add(currentUrl, 'current-page', { current: true });
  }

  // Reserve one deterministic sample for content types that commonly hide crawl-relevant
  // state behind browser interaction (catalogue/page-flipper, publication viewer, live/video).
  // This is not evidence by itself; it only ensures that a minority high-fidelity section is
  // actually tested rather than being missed by broad section sampling.
  const riskPool = dedup
    .filter(c => c.segs.some(seg => HIGH_FIDELITY_RISK_SEGMENTS.has(seg.toLowerCase())))
    .filter(c => !chosen.some(x => sameUrl(x.url, c.url)))
    .map(c => ({
      ...c,
      riskScore: c.segs.reduce((n, seg) => n + (HIGH_FIDELITY_RISK_SEGMENTS.has(seg.toLowerCase()) ? 10 : 0), 0)
        + (c.depth >= 2 && c.depth <= 4 ? 8 : 0)
        + (c.ts ? 4 : 0)
    }))
    .sort((a,b) => b.riskScore - a.riskScore || b.ts - a.ts || a.url.length - b.url.length);
  if (riskPool.length && chosen.length < max) add(riskPool[0].url, 'interaction-risk', sampleMeta(riskPool[0], { prefix: riskPool[0].segs[0]?.toLowerCase() || '' }));

  const sectionPool = dedup.filter(c => c.depth >= 1 && c.depth <= 2)
    .map(c => ({
      ...c,
      prefix: c.segs[0].toLowerCase(),
      score: (prefixCounts.get(c.segs[0].toLowerCase()) || 0) * 4
        + (c.depth === 1 ? 20 : 7)
        + (c.url.endsWith('/') ? 3 : 0)
        + (SPECIAL_SEGMENTS.has(c.segs[c.segs.length - 1].toLowerCase()) ? 6 : 0)
        + Math.min(5, c.ts ? 5 : 0)
    }))
    .sort((a,b) => b.score - a.score || b.ts - a.ts || a.url.length - b.url.length);

  const sectionPrefixes = new Set();
  for (const c of sectionPool) {
    if (chosen.length >= max - 1) break; // reserve some room for a detail sample
    if (sectionPrefixes.has(c.prefix)) continue;
    if ((prefixCounts.get(c.prefix) || 0) < 2 && sectionPrefixes.size >= 1) continue;
    if (add(c.url, 'section', sampleMeta(c, { prefix: c.prefix }))) sectionPrefixes.add(c.prefix);
    if (sectionPrefixes.size >= 3) break;
  }

  const detailPool = dedup.filter(c => c.depth >= 2)
    .filter(c => !/\/(?:page|side)\/\d+\/?$/i.test(new URL(c.url).pathname))
    .sort((a,b) => Number(Boolean(b.sitemapPool)) - Number(Boolean(a.sitemapPool))
      || (a.sitemapLanguagePriority ?? 9) - (b.sitemapLanguagePriority ?? 9)
      || b.ts - a.ts || b.depth - a.depth || a.url.length - b.url.length);

  for (const prefix of sectionPrefixes) {
    if (chosen.length >= max) break;
    const d = detailPool.find(c => c.segs[0].toLowerCase() === prefix && !chosen.some(x => sameUrl(x.url, c.url)));
    if (d) add(d.url, 'detail', sampleMeta(d, { prefix }));
  }

  if (chosen.length < max) {
    const special = dedup.find(c => c.segs.some(s => SPECIAL_SEGMENTS.has(s.toLowerCase())) && !chosen.some(x => sameUrl(x.url, c.url)));
    if (special) add(special.url, 'central-page', sampleMeta(special));
  }

  // Use remaining slots to improve sitemap-source diversity. This does not force one
  // final sample per sitemap when there are more sitemaps than the user's sample limit;
  // it simply avoids repeatedly drawing supplements from the same sitemap when equally
  // useful candidates from other fetched sitemaps are available.
  const representedSitemaps = new Set(chosen.map(x => x.sourceSitemap).filter(x => x && x !== 'rendered-frontpage'));
  for (const pool of sitemapPools) {
    if (chosen.length >= max) break;
    if (representedSitemaps.has(pool.sitemapUrl)) continue;
    const c = detailPool.find(x => x.sourceSitemap === pool.sitemapUrl && !chosen.some(y => sameUrl(y.url, x.url)))
      || dedup.find(x => x.sourceSitemap === pool.sitemapUrl && !chosen.some(y => sameUrl(y.url, x.url)));
    if (!c) continue;
    if (add(c.url, 'sitemap-diversity', sampleMeta(c, { prefix: c.segs[0]?.toLowerCase() || '' }))) representedSitemaps.add(pool.sitemapUrl);
  }

  for (const c of detailPool) {
    if (chosen.length >= max) break;
    add(c.url, 'detail-supplement', sampleMeta(c, { prefix: c.segs[0]?.toLowerCase() || '' }));
  }

  return chosen.slice(0, max);
}

function pathSegments(u) {
  return u.pathname.split('/').filter(Boolean).map(x => decodeURIComponentSafe(x));
}
function decodeURIComponentSafe(s) { try { return decodeURIComponent(s); } catch { return s; } }

function selectRenderTargets(samples, currentUrl, max) {
  const out = [];
  const add = s => {
    if (s && !out.some(x => sameUrl(x.url, s.url))) out.push(s);
  };

  // The active page is always one of the browser-rendered samples.
  add(samples.find(s => sameUrl(s.url, currentUrl)) || { url: currentUrl, role: 'current-page', current: true });

  const order = ['front-page+current-page','front-page','interaction-risk','section','detail','central-page','sitemap-diversity','detail-supplement'];
  for (const role of order) {
    for (const s of samples.filter(x => x.role === role)) {
      add(s);
      if (out.length >= max) return out.slice(0, max);
    }
  }
  return out.slice(0, max);
}

const UNSAFE_SAMPLE_EXT_RE = /\.(?:pdf|doc|docx|dot|dotx|xls|xlsx|xlsm|ods|csv|tsv|ppt|pptx|pps|ppsx|odp|rtf|odt|epub|mobi|azw3|ps|eps|zip|rar|7z|tar|tgz|gz|bz2|xz|zst|iso|dmg|pkg|exe|msi|msix|appx|apk|deb|rpm|bin|torrent|jpg|jpeg|png|gif|webp|avif|svg|ico|mp4|m4v|mov|avi|mkv|webm|mp3|m4a|aac|ogg|wav|flac|woff|woff2|ttf|otf|css|js|mjs|xml|json)(?:$|[?#])/i;

function isUnsafeBrowserSampleUrl(url) {
  try {
    const u = new URL(url);
    if (!/^https?:$/.test(u.protocol)) return true;
    if (UNSAFE_SAMPLE_EXT_RE.test(`${u.pathname}${u.search}`)) return true;
    const q = `${u.pathname} ${u.search}`;
    if (/[?&](?:download|attachment|export|filename|file)=(?:1|true|yes|[^&]+\.(?:pdf|docx?|xlsx?|pptx?|zip|csv))(?:&|$)/i.test(q)) return true;
    return false;
  } catch { return true; }
}

function looksLikeHtmlText(text) {
  const head = String(text || '').slice(0, 12000).replace(/^\uFEFF/, '').trimStart().toLowerCase();
  if (!head) return false;
  if (head.includes('\u0000')) return false;
  return /^<!doctype\s+html\b/.test(head) || /^<html\b/.test(head) || /<(?:html|head|body|main|article|nav|section|div)(?:\s|>)/.test(head);
}

function assessBrowserSampleSafety(originalUrl, res, rootDomain) {
  if (isUnsafeBrowserSampleUrl(originalUrl)) return { safe: false, reason: 'file-like-url', htmlLike: false };
  if (!res || res.error) return { safe: false, reason: 'preflight-failed', htmlLike: false };
  const finalUrl = res.finalUrl || originalUrl;
  if (isUnsafeBrowserSampleUrl(finalUrl)) return { safe: false, reason: 'redirected-to-file', htmlLike: false };
  if (!/^https?:/i.test(finalUrl) || !sameRegisteredDomain(finalUrl, rootDomain)) return { safe: false, reason: 'redirect-outside-domain', htmlLike: false };
  if (/\battachment\b/i.test(res.contentDisposition || '')) return { safe: false, reason: 'content-disposition-attachment', htmlLike: false };
  const ct = String(res.contentType || '').toLowerCase();
  const explicitHtml = /(?:text\/html|application\/xhtml\+xml)/i.test(ct);
  const dangerousMime = /(?:application\/(?:pdf|msword|vnd\.|octet-stream|zip|x-7z|x-rar|x-tar)|image\/|audio\/|video\/|font\/)/i.test(ct);
  if (dangerousMime) return { safe: false, reason: 'non-html-mime', htmlLike: false };
  const sniffedHtml = looksLikeHtmlText(res.text);
  const htmlLike = explicitHtml || ((!ct || /^text\/plain/i.test(ct)) && sniffedHtml);
  if (!htmlLike) return { safe: false, reason: 'html-not-confirmed', htmlLike: false };
  return { safe: true, reason: 'confirmed-html', htmlLike: true };
}

async function fetchPage(url) {
  const res = await fetchText(url, CONFIG.MAX_HTML_BYTES, 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.1');
  return res;
}

async function fetchText(url, maxBytes, accept = 'application/xml,text/xml,text/plain,text/html,*/*;q=0.1', timeoutMs = CONFIG.FETCH_TIMEOUT_MS) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      method: 'GET',
      redirect: 'follow',
      cache: 'no-store',
      credentials: 'omit',
      headers: { 'Accept': accept },
      signal: ctrl.signal,
    });
    const bytes = await readBytesLimited(response.body, maxBytes);
    const text = await decodeMaybeGzip(bytes, maxBytes * 2);
    return {
      ok: response.ok,
      status: response.status,
      finalUrl: response.url,
      contentType: response.headers.get('content-type') || '',
      contentDisposition: response.headers.get('content-disposition') || '',
      contentLength: Number(response.headers.get('content-length') || 0) || 0,
      text,
      truncated: bytes.truncated,
    };
  } finally {
    clearTimeout(timer);
  }
}

async function readBytesLimited(stream, maxBytes) {
  if (!stream) return Object.assign(new Uint8Array(), { truncated: false });
  const reader = stream.getReader();
  const chunks = [];
  let total = 0, truncated = false;
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    if (total + value.byteLength > maxBytes) {
      const remain = maxBytes - total;
      if (remain > 0) chunks.push(value.slice(0, remain));
      total = maxBytes;
      truncated = true;
      try { await reader.cancel(); } catch {}
      break;
    }
    chunks.push(value); total += value.byteLength;
  }
  const out = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) { out.set(c, off); off += c.byteLength; }
  out.truncated = truncated;
  return out;
}

async function decodeMaybeGzip(bytes, maxOut) {
  if (bytes.length >= 2 && bytes[0] === 0x1f && bytes[1] === 0x8b && 'DecompressionStream' in self) {
    try {
      const ds = new DecompressionStream('gzip');
      const stream = new Blob([bytes]).stream().pipeThrough(ds);
      const out = await readBytesLimited(stream, maxOut);
      return new TextDecoder().decode(out);
    } catch {}
  }
  return new TextDecoder().decode(bytes);
}

function analyzeRawHtml(html, url, rootDomain) {
  const text = html || '';
  const links = [];
  const hrefRe = /<a\b[^>]*\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/gi;
  let m;
  while ((m = hrefRe.exec(text)) && links.length < 5000) {
    const raw = m[1] ?? m[2] ?? m[3] ?? '';
    try {
      const abs = new URL(xmlUnescape(raw), url);
      if (/^https?:$/.test(abs.protocol) && registrableDomain(abs.hostname) === rootDomain) {
        abs.hash = ''; links.push(abs.href);
      }
    } catch {}
  }
  const stripped = text
    .replace(/<script\b[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style\b[\s\S]*?<\/style>/gi, ' ')
    .replace(/<noscript\b[\s\S]*?<\/noscript>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;|&#160;/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  const scriptSrcs = [...text.matchAll(/<script\b[^>]*\bsrc\s*=\s*["']([^"']+)["']/gi)].map(x => x[1]).slice(0, 200);
  const low = text.toLowerCase();
  const rawStreamingManifestUrls = [...text.matchAll(/(?:https?:)?\/\/[^\s\"'<>]+(?:\.m3u8|\.mpd)(?:[?#][^\s\"'<>]*)?|[^\s\"'<>]+(?:\.m3u8|\.mpd)(?:[?#][^\s\"'<>]*)?/gi)].map(x => x[0]).slice(0, 30);
  const frameworks = [];
  if (/__next_data__|\/_next\//i.test(text)) frameworks.push('Next.js');
  if (/__nuxt__|\/_nuxt\//i.test(text)) frameworks.push('Nuxt/Vue');
  if (/ng-version=|angular/i.test(text)) frameworks.push('Angular');
  if (/data-reactroot|react-dom|react\.production/i.test(text) || scriptSrcs.some(x => /react/i.test(x))) frameworks.push('React');
  if (/data-v-[0-9a-f]{6,}/i.test(text)) frameworks.push('Vue');

  // Approximate the URL set a non-rendering crawler can discover from the initial
  // representation. This intentionally goes beyond <a href>: Heritrix can extract
  // resources from common HTML attributes, CSS and many URL-like strings in JS/JSON.
  const staticUrls = new Set();
  const addStaticUrl = raw => {
    if (!raw || staticUrls.size >= CONFIG.MAX_STATIC_URLS) return;
    try {
      const u = new URL(xmlUnescape(String(raw).trim()), url);
      if (/^https?:$/.test(u.protocol)) { u.hash = ''; staticUrls.add(u.href); }
    } catch {}
  };
  for (const mm of text.matchAll(/\b(?:href|src|action|poster|data-src|data-lazy-src|data-original)\s*=\s*(?:"([^"]+)"|'([^']+)'|([^\s>]+))/gi)) addStaticUrl(mm[1] ?? mm[2] ?? mm[3]);
  for (const mm of text.matchAll(/\bsrcset\s*=\s*(?:"([^"]+)"|'([^']+)')/gi)) {
    for (const part of (mm[1] ?? mm[2] ?? '').split(',')) addStaticUrl(part.trim().split(/\s+/)[0]);
  }
  for (const mm of text.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/gi)) addStaticUrl(mm[1]);
  // Restrict quoted-string extraction to URL/path shapes that are plausibly crawl-relevant
  // to avoid treating arbitrary application strings as URLs.
  for (const mm of text.matchAll(/["']((?:https?:)?\/\/[^"'\s<>]+|\/(?:api|graphql|ajax|wp-json|_next|media|video|audio|image|images|page|pages|tile|tiles|content|feed|live)[^"'\s<>]*)["']/gi)) addStaticUrl(mm[1]);

  return {
    htmlLength: text.length,
    textLength: stripped.length,
    internalLinkCount: new Set(links).size,
    scriptCount: (text.match(/<script\b/gi) || []).length,
    externalScriptCount: scriptSrcs.length,
    frameworks: [...new Set(frameworks)],
    buttons: (text.match(/<button\b/gi) || []).length,
    iframes: (text.match(/<iframe\b/gi) || []).length,
    lazyStandard: (text.match(/\bloading\s*=\s*["']lazy["']/gi) || []).length,
    lazyDataSrc: (text.match(/\bdata-(?:src|lazy-src|original)\s*=/gi) || []).length,
    jsonLd: (text.match(/application\/ld\+json/gi) || []).length,
    noscript: (text.match(/<noscript\b/gi) || []).length,
    loadMoreText: /(?:load|show|view)\s+more|se\s+flere|vis\s+flere|indlæs\s+flere|flere\s+(?:kommentarer|resultater|artikler)/i.test(stripped),
    apiHints: (low.match(/(?:\/api\/|graphql|ajax|wp-json|_next\/data)/g) || []).length,
    mediaElements: (text.match(/<(?:video|audio)\b/gi) || []).length,
    streamingManifestHints: rawStreamingManifestUrls.length,
    streamingManifestUrls: rawStreamingManifestUrls,
    challenge: /just a moment|checking your browser|verify you are human|access denied|cf-chl-|cloudflare ray id|akamai|incapsula|imperva|captcha|bot detection/i.test(stripped + ' ' + low.slice(0, 120000)),
    links: [...new Set(links)].slice(0, 2500),
    staticUrls: [...staticUrls],
    websocketHints: (low.match(/(?:new\s+websocket\s*\(|\bwss?:\/\/)/g) || []).length,
    eventSourceHints: (low.match(/(?:new\s+eventsource\s*\(|text\/event-stream)/g) || []).length,
    graphQlHints: (low.match(/graphql/g) || []).length,
    cursorPaginationHints: (low.match(/(?:endcursor|hasnextpage|pageinfo|nextcursor|cursor\s*[:=])/g) || []).length,
  };
}

async function createIsolatedTestWindow(rootTabId, rootDomain) {
  if (activeTestSession) throw new Error('Another secure browser test session is already running.');
  const allowed = await chrome.extension.isAllowedIncognitoAccess();
  if (!allowed) throw new Error('Incognito access is required. Enable “Allow in Incognito” for this extension in chrome://extensions.');

  // Chrome Incognito windows share one temporary cookie jar. Requiring that no other
  // Incognito window is open ensures the test starts with a fresh, unauthenticated state
  // and prevents automated probes from touching an existing private session.
  const existing = await chrome.windows.getAll({ populate: false });
  if (existing.some(w => w.incognito)) {
    throw new Error('For a fresh isolated test session, close existing Incognito windows and run the analysis again.');
  }

  let win = null;
  try {
    win = await chrome.windows.create({
      url: 'about:blank', type: 'normal', incognito: true, focused: false, state: 'minimized',
    });
  } catch (firstError) {
    try {
      win = await chrome.windows.create({ url: 'about:blank', type: 'normal', incognito: true, focused: false });
      if (!win?.id) throw new Error('Chrome did not return a test window ID.');
      await chrome.windows.update(win.id, { state: 'minimized', focused: false });
    } catch (fallbackError) {
      if (win?.id != null) await chrome.windows.remove(win.id).catch(() => {});
      throw new Error(`Could not create a minimized Incognito test window: ${fallbackError?.message || fallbackError || firstError}`);
    }
  }
  if (!win?.id) throw new Error('Chrome did not return a test window ID.');
  activeTestSession = { windowId: win.id, rootTabId, rootDomain, tabIds: new Set(), tabSecurity: new Map(), securityEvents: [], securityAbort: null, blockedDownload: null, startedAt: Date.now() };
  return activeTestSession;
}

async function renderInBackgroundTab(url, rootDomain, windowId) {
  if (windowId == null) throw new Error('Missing isolated test window.');
  if (isUnsafeBrowserSampleUrl(url)) return { securityLimited: true, securityReason: 'security-preflight-rejected-url', securityEvents: [] };
  const tab = await chrome.tabs.create({ url: 'about:blank', active: false, windowId });
  activeTestSession?.tabIds?.add(tab.id);
  const tabState = getTabSecurityState(activeTestSession, tab.id);
  if (tabState) tabState.currentUrl = 'about:blank';
  try {
    try {
      await chrome.tabs.update(tab.id, { url });
      await waitForTabComplete(tab.id, CONFIG.TAB_TIMEOUT_MS).catch(() => {});
    } catch (err) {
      const events = securityEventsForTab(activeTestSession, tab.id);
      if (events.length) return { securityLimited: true, securityEvents: events, technicalDetail: String(err) };
      return { error: String(err) };
    }

    let finalTab;
    try { finalTab = await chrome.tabs.get(tab.id); }
    catch (err) {
      const events = securityEventsForTab(activeTestSession, tab.id);
      if (events.length) return { securityLimited: true, securityEvents: events, technicalDetail: String(err) };
      return { error: String(err) };
    }

    if (activeTestSession?.securityAbort) throw new Error(activeTestSession.securityAbort.reason);
    if (!finalTab.url || !/^https?:/i.test(finalTab.url) || !sameRegisteredDomain(finalTab.url, rootDomain) || isUnsafeBrowserSampleUrl(finalTab.url)) {
      const events = securityEventsForTab(activeTestSession, tab.id);
      return {
        securityLimited: true,
        securityReason: events.at(-1)?.type || 'top-level-navigation-not-testable',
        securityEvents: events,
        finalUrl: finalTab.url || '',
      };
    }

    let base = null;
    try {
      base = await probeTab(tab.id, true);
    } catch (err) {
      const events = securityEventsForTab(activeTestSession, tab.id);
      // Preserve the sample as valid even if an active probe was curtailed. Raw HTML and
      // other samples remain usable evidence; this is not an archival-content error.
      if (events.length) return { securityLimited: true, securityEvents: events, technicalDetail: String(err), finalUrl: finalTab.url || url };
      return { testLimited: true, testLimitReason: 'browser-probe-error', technicalDetail: String(err), finalUrl: finalTab.url || url };
    }

    let viewer = { detected: false, frames: [], strongClicks: 0, testedClicks: 0 };
    try {
      viewer = await probeEmbeddedViewers(tab.id);
    } catch (err) {
      recordTabSecurityEvent(activeTestSession, tab.id, 'viewer-probe-limited', String(err));
    }

    const events = securityEventsForTab(activeTestSession, tab.id);
    return {
      ...(base || {}),
      viewer,
      securityLimited: false,
      securityEvents: events,
      safeguardsTriggered: events.length > 0,
    };
  } finally {
    activeTestSession?.tabIds?.delete(tab.id);
    activeTestSession?.tabSecurity?.delete(tab.id);
    await chrome.tabs.remove(tab.id).catch(() => {});
  }
}

async function probeEmbeddedViewers(tabId) {
  // Specialized probe for page-flippers, digital catalogues, PDF/publication viewers,
  // lightboxes and embedded document readers. Unlike the general click test, this runs
  // in ALL accessible frames and treats click-triggered image/page/tile resources as
  // crawl-relevant data loading even when no XHR/fetch or new text node is produced.
  const executions = await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    world: 'MAIN',
    func: async (opts) => {
      const wait = ms => new Promise(r => setTimeout(r, ms));
      const norm = value => { try { return new URL(value, location.href).href; } catch { return ''; } };
      const visible = el => {
        try {
          const r = el.getBoundingClientRect();
          const st = getComputedStyle(el);
          return r.width >= 8 && r.height >= 8 && st.display !== 'none' && st.visibility !== 'hidden' && Number(st.opacity || 1) > 0;
        } catch { return false; }
      };
      const normalHref = el => {
        const a = el.closest?.('a[href]');
        if (!a) return false;
        const raw = (a.getAttribute('href') || '').trim();
        if (!raw || raw === '#' || /^javascript:/i.test(raw)) return false;
        try { return /^https?:$/i.test(new URL(raw, location.href).protocol); } catch { return false; }
      };
      const dangerous = el => {
        const d = `${el.innerText || el.textContent || ''} ${el.getAttribute?.('aria-label') || ''} ${el.getAttribute?.('title') || ''}`;
        return /(?:delete|remove|logout|log\s*out|sign\s*out|login|sign\s*in|buy|purchase|checkout|order|pay|subscribe|unsubscribe|submit|save|confirm|accept|reject|cookie|consent|download|print|share|follow|like|report|block|book|reservation|slet|log\s*ud|log\s*ind|køb|betal|bestil|abonn|tilmeld|afmeld|send|gem|bekræft|accepter|afvis|samtykke|del\b)/i.test(d)
          || el.matches?.('input[type="submit"],button[type="submit"],[formaction]')
          || !!el.closest?.('form')
          || !!el.closest?.('a[download]');
      };
      const attrText = el => {
        const svg = el.querySelector?.('svg');
        const use = svg?.querySelector?.('use');
        return [
          el.innerText || el.textContent || '',
          el.getAttribute?.('aria-label') || '', el.getAttribute?.('title') || '',
          el.getAttribute?.('name') || '', el.getAttribute?.('data-testid') || '',
          el.getAttribute?.('data-test') || '', el.getAttribute?.('data-cy') || '',
          el.id || '', typeof el.className === 'string' ? el.className : '',
          svg?.getAttribute?.('aria-label') || '', svg?.getAttribute?.('data-icon') || '',
          use?.getAttribute?.('href') || use?.getAttribute?.('xlink:href') || ''
        ].join(' ').replace(/\s+/g,' ').trim();
      };
      const viewerRe = /(?:catalog|catalogue|katalog|tilbudsavis|publication|publikation|leaflet|brochure|magazine|flip(?:book|per)?|page[-_ ]?flip|page[-_ ]?turn|document[-_ ]?viewer|pdf[-_ ]?viewer|reader|spread|digital[-_ ]?edition)/i;
      const nextRe = /(?:^|[-_\s])(next|næste|forward|frem|right|page[-_ ]?next|next[-_ ]?page|next[-_ ]?slide|navigate[-_ ]?next|arrow[-_ ]?right|chevron[-_ ]?right|caret[-_ ]?right|turn[-_ ]?right|flip[-_ ]?next)(?:$|[-_\s])/i;
      const prevRe = /(?:^|[-_\s])(prev|previous|forrige|back|left|arrow[-_ ]?left|chevron[-_ ]?left|caret[-_ ]?left)(?:$|[-_\s])/i;
      const resourceNoise = /(?:google-analytics|googletagmanager|doubleclick|facebook\.com\/tr|hotjar|clarity\.ms|matomo|plausible|segment\.|sentry|telemetry|analytics|metrics|\/collect(?:\?|$)|beacon|adservice|adsystem|tracking|favicon|font|woff2?|ttf)(?:[/?#]|$)/i;
      const pageAssetRe = /(?:\.(?:jpe?g|png|webp|avif|gif|svg|pdf)(?:[?#]|$)|\/(?:page|pages|spread|spreads|sheet|sheets|tile|tiles|image|images|render|renders|publication|catalog|catalogue|katalog|leaflet|brochure|magazine)(?:[\/_?&#.-]|$)|[?&](?:page|pagenumber|pageindex|sheet|spread|tile|zoom)=)/i;

      const imageUrls = () => {
        const out = new Set();
        for (const img of document.querySelectorAll('img')) {
          for (const v of [img.currentSrc, img.src, img.getAttribute('src'), img.getAttribute('data-src'), img.getAttribute('data-lazy-src')]) {
            const u = norm(v || ''); if (/^https?:/i.test(u)) out.add(u);
          }
          const ss = img.getAttribute('srcset') || '';
          for (const part of ss.split(',')) { const u = norm(part.trim().split(/\s+/)[0] || ''); if (/^https?:/i.test(u)) out.add(u); }
        }
        for (const el of document.querySelectorAll('[style*="background" i]')) {
          const bg = getComputedStyle(el).backgroundImage || '';
          for (const m of bg.matchAll(/url\(["']?([^"')]+)["']?\)/g)) { const u = norm(m[1]); if (/^https?:/i.test(u)) out.add(u); }
        }
        return out;
      };
      const canvasFingerprint = () => {
        const vals = [];
        for (const c of [...document.querySelectorAll('canvas')].slice(0,4)) {
          try {
            const ctx = c.getContext('2d', { willReadFrequently: true });
            if (!ctx || !c.width || !c.height) { vals.push(`${c.width}x${c.height}:na`); continue; }
            const pts = [[.2,.2],[.5,.5],[.8,.8],[.2,.8],[.8,.2]];
            let h = 2166136261;
            for (const [px,py] of pts) {
              const d = ctx.getImageData(Math.min(c.width-1,Math.max(0,Math.floor(c.width*px))), Math.min(c.height-1,Math.max(0,Math.floor(c.height*py))), 1, 1).data;
              for (const b of d) { h ^= b; h = Math.imul(h,16777619); }
            }
            vals.push(`${c.width}x${c.height}:${h>>>0}`);
          } catch { vals.push(`${c.width}x${c.height}:tainted`); }
        }
        return vals.join('|');
      };
      const snapshot = () => ({
        url: location.href,
        images: imageUrls(),
        canvases: document.querySelectorAll('canvas').length,
        canvasFp: canvasFingerprint(),
        elements: document.body?.querySelectorAll('*').length || 0,
        text: document.body?.innerText?.length || 0,
        resources: new Set(performance.getEntriesByType('resource').map(e => e.name || '').filter(Boolean)),
      });

      const docDescriptor = `${location.href} ${document.title || ''} ${document.body?.className || ''}`;
      const viewerContainers = [...document.querySelectorAll('[class*="viewer" i],[id*="viewer" i],[class*="flip" i],[id*="flip" i],[class*="catalog" i],[id*="catalog" i],[class*="katalog" i],[id*="katalog" i],[class*="publication" i],[id*="publication" i],[class*="reader" i],[id*="reader" i],[class*="leaflet" i],[class*="magazine" i]')].filter(visible);
      const largeOverlay = [...document.querySelectorAll('body *')].find(el => {
        if (!visible(el)) return false;
        try {
          const r = el.getBoundingClientRect(), st = getComputedStyle(el);
          return ['fixed','absolute'].includes(st.position) && r.width >= innerWidth*.65 && r.height >= innerHeight*.55 && Number(st.zIndex || 0) >= 10;
        } catch { return false; }
      });
      const viewerish = viewerRe.test(docDescriptor)
        || viewerContainers.length > 0
        || (document.querySelectorAll('canvas').length > 0 && document.querySelectorAll('button,[role="button"]').length >= 2)
        || !!largeOverlay;

      const controls = [...document.querySelectorAll('button,[role="button"],input[type="button"],[tabindex]:not(a)')]
        .filter(el => visible(el) && !normalHref(el) && !dangerous(el) && !el.disabled && el.getAttribute?.('aria-disabled') !== 'true');
      let candidate = controls.find(el => nextRe.test(` ${attrText(el)} `) && !prevRe.test(` ${attrText(el)} `));
      const explicitNextControl = !!candidate;

      // Many page-flippers use icon-only left/right arrows. Spatial inference is only
      // allowed when we also see viewer structure (viewer container/canvas) or a
      // symmetric pair of edge controls, so a random right-side site button is not clicked.
      const scope = viewerContainers[0] || largeOverlay || document.documentElement;
      const sr = scope.getBoundingClientRect?.() || { left:0, top:0, width:innerWidth, height:innerHeight };
      const scopedControls = controls
        .filter(el => scope === document.documentElement || scope.contains(el))
        .map(el => ({ el, r: el.getBoundingClientRect(), d: attrText(el) }));
      const midBand = x => x.r.top + x.r.height/2 > sr.top + sr.height*.12 && x.r.top + x.r.height/2 < sr.top + sr.height*.88;
      const hasLeftEdgeControl = scopedControls.some(x => midBand(x) && x.r.left + x.r.width/2 < sr.left + sr.width*.35);
      const hasRightEdgeControl = scopedControls.some(x => midBand(x) && x.r.left + x.r.width/2 > sr.left + sr.width*.65);
      const edgeControlPair = hasLeftEdgeControl && hasRightEdgeControl;
      const structuralViewer = viewerContainers.length > 0 || document.querySelectorAll('canvas').length > 0 || edgeControlPair;

      if (!candidate && viewerish && structuralViewer) {
        candidate = scopedControls
          .filter(x => midBand(x) && x.r.left + x.r.width/2 > sr.left + sr.width*.62)
          .filter(x => !prevRe.test(` ${x.d} `))
          .sort((a,b) => (b.r.left+b.r.width/2) - (a.r.left+a.r.width/2))[0]?.el || null;
      }

      if (!candidate) return { frameUrl: location.href, viewerish, tested: false, strong: false, reason: viewerish ? 'viewer-no-next-control' : 'not-viewer' };

      const before = snapshot();
      const beforeDescriptor = attrText(candidate).slice(0,180);
      let addedElements = 0, changedImageAttrs = 0, changedStyleAttrs = 0;
      const mo = new MutationObserver(ms => {
        for (const m of ms) {
          if (m.type === 'childList') for (const n of m.addedNodes) if (n.nodeType === Node.ELEMENT_NODE) addedElements++;
          if (m.type === 'attributes') {
            if (m.target?.tagName === 'IMG' && ['src','srcset'].includes(m.attributeName)) changedImageAttrs++;
            if (m.attributeName === 'style') changedStyleAttrs++;
          }
        }
      });
      try { mo.observe(document.documentElement, { subtree:true, childList:true, attributes:true, attributeFilter:['src','srcset','style'] }); } catch {}
      const blockedAnchorHref = a => {
        if (!a) return false;
        const href = (a.getAttribute?.('href') || '').trim();
        return a.hasAttribute?.('download') || /^(?:blob:|data:|file:)/i.test(href) || /\.(?:pdf|docx?|xlsx?|pptx?|zip|rar|7z|csv|exe|msi|dmg|apk)(?:$|[?#])/i.test(href);
      };
      const blockDownloadClick = e => {
        const a = e.target?.closest?.('a');
        if (blockedAnchorHref(a)) { e.preventDefault(); e.stopImmediatePropagation(); }
      };
      const installNetworkSafety = () => {
        const originalFetch = window.fetch;
        const xhrOpen = XMLHttpRequest.prototype.open;
        const xhrSend = XMLHttpRequest.prototype.send;
        const originalBeacon = navigator.sendBeacon?.bind(navigator);
        const safeMethod = (method, url, body) => {
          method = String(method || 'GET').toUpperCase();
          if (['GET','HEAD','OPTIONS'].includes(method)) return true;
          const b = typeof body === 'string' ? body : '';
          return method === 'POST' && /graphql/i.test(String(url || '')) && !/\bmutation\b/i.test(b) && /(?:query|operationName|variables)/i.test(b);
        };
        try {
          window.fetch = function(input, init = {}) {
            const url = typeof input === 'string' ? input : input?.url || '';
            const method = init?.method || input?.method || 'GET';
            if (!safeMethod(method, url, init?.body)) return Promise.reject(new TypeError('Blocked by Crawler Choice safety policy'));
            return originalFetch.apply(this, arguments);
          };
          XMLHttpRequest.prototype.open = function(method, url, ...rest) { this.__ccMethod = method; this.__ccUrl = url; return xhrOpen.call(this, method, url, ...rest); };
          XMLHttpRequest.prototype.send = function(body) { if (!safeMethod(this.__ccMethod, this.__ccUrl, body)) { try { this.abort(); } catch {} return; } return xhrSend.call(this, body); };
          if (navigator.sendBeacon) navigator.sendBeacon = () => false;
        } catch {}
        return () => {
          try { window.fetch = originalFetch; XMLHttpRequest.prototype.open = xhrOpen; XMLHttpRequest.prototype.send = xhrSend; if (originalBeacon) navigator.sendBeacon = originalBeacon; } catch {}
        };
      };
      const seenResources = [];
      let po = null;
      try {
        po = new PerformanceObserver(list => { for (const e of list.getEntries()) if (e.name && !resourceNoise.test(e.name)) seenResources.push({url:e.name,type:e.initiatorType || ''}); });
        po.observe({ type:'resource' });
      } catch {}

      const blockSubmit = e => { e.preventDefault(); e.stopImmediatePropagation(); };
      const originalOpenForViewer = window.open;
      const originalAnchorClickForViewer = HTMLAnchorElement.prototype.click;
      const restoreNetworkSafety = installNetworkSafety();
      try {
        document.addEventListener('submit', blockSubmit, true);
        document.addEventListener('click', blockDownloadClick, true);
        window.open = () => null;
        HTMLAnchorElement.prototype.click = function(...args) { if (blockedAnchorHref(this)) return; return originalAnchorClickForViewer.apply(this, args); };
      } catch {}
      try {
        candidate.scrollIntoView?.({block:'center',inline:'nearest',behavior:'auto'});
        await wait(100);
        candidate.click();
        await wait(opts.settleMs || 1800);
      } catch {} finally {
        restoreNetworkSafety();
        try {
          document.removeEventListener('submit', blockSubmit, true);
          document.removeEventListener('click', blockDownloadClick, true);
          window.open = originalOpenForViewer;
          HTMLAnchorElement.prototype.click = originalAnchorClickForViewer;
        } catch {}
      }
      try { mo.disconnect(); po?.disconnect(); } catch {}
      const after = snapshot();
      const newResources = [...after.resources].filter(u => !before.resources.has(u) && !resourceNoise.test(u));
      for (const e of seenResources) if (!newResources.includes(e.url)) newResources.push(e.url);
      const newImages = [...after.images].filter(u => !before.images.has(u));
      const pageResources = newResources.filter(u => pageAssetRe.test(u));
      const resourceTypes = seenResources.filter(e => newResources.includes(e.url));
      const imageTypeResources = resourceTypes.filter(e => /^(?:img|image)$/i.test(e.type) || pageAssetRe.test(e.url));
      const routeChanged = after.url !== before.url;
      const canvasChanged = !!before.canvasFp && !!after.canvasFp && before.canvasFp !== after.canvasFp && !/tainted/.test(before.canvasFp + after.canvasFp);
      const visualChanged = newImages.length > 0 || changedImageAttrs > 0 || canvasChanged || changedStyleAttrs >= 2 || addedElements >= 2;
      const loadedPageAssets = pageResources.length > 0 || imageTypeResources.length > 0 || newImages.length > 0;
      const strong = viewerish && (explicitNextControl || structuralViewer) && loadedPageAssets && (visualChanged || routeChanged);

      return {
        frameUrl: location.href,
        viewerish,
        tested: true,
        strong,
        label: beforeDescriptor,
        routeChanged,
        newResources: newResources.slice(0,12),
        pageResources: pageResources.slice(0,12),
        newImages: newImages.slice(0,8),
        addedElements,
        changedImageAttrs,
        changedStyleAttrs,
        canvasChanged,
        canvasCount: after.canvases,
      };
    },
    args: [{ settleMs: CONFIG.VIEWER_CLICK_SETTLE_MS }],
  });

  const frames = executions
    .map(x => ({ frameId: x.frameId, ...(x.result || {}) }))
    .filter(x => x && x.frameUrl)
    .slice(0, CONFIG.VIEWER_MAX_FRAME_PROBES);
  const tested = frames.filter(x => x.tested);
  const strong = tested.filter(x => x.strong);
  return {
    detected: frames.some(x => x.viewerish),
    testedClicks: tested.length,
    strongClicks: strong.length,
    strongFrames: strong.map(x => ({ frameId:x.frameId, frameUrl:x.frameUrl, label:x.label, routeChanged:x.routeChanged, pageResources:x.pageResources, newImages:x.newImages, canvasChanged:x.canvasChanged })),
    frames,
  };
}

async function waitForTabComplete(tabId, timeoutMs) {
  try {
    const t = await chrome.tabs.get(tabId);
    if (t.status === 'complete') return;
  } catch {}
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { cleanup(); reject(new Error('Render timeout')); }, timeoutMs);
    const listener = (id, info) => {
      if (id === tabId && info.status === 'complete') { cleanup(); resolve(); }
    };
    function cleanup() { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(listener); }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function probeTab(tabId, scrollTest) {
  const scrollOptions = {
    maxMs: CONFIG.SCROLL_MAX_MS,
    maxSteps: CONFIG.SCROLL_MAX_STEPS,
    stableBottomRounds: CONFIG.SCROLL_STABLE_BOTTOM_ROUNDS,
    maxBottomLoads: CONFIG.SCROLL_MAX_BOTTOM_LOADS,
    clickMaxCandidates: CONFIG.CLICK_TEST_MAX_CANDIDATES,
    clickSettleMs: CONFIG.CLICK_TEST_SETTLE_MS,
    mediaPlaybackTestMs: CONFIG.MEDIA_PLAYBACK_TEST_MS,
    mediaMaxElements: CONFIG.MEDIA_MAX_ELEMENTS,
  };
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: async (doScroll, opts) => {
      const wait = ms => new Promise(r => setTimeout(r, ms));
      const norm = href => { try { const u = new URL(href, location.href); u.hash = ''; return u.href; } catch { return ''; } };
      try { performance.setResourceTimingBufferSize?.(5000); } catch {}

      const manifestRe = /(?:\.m3u8|\.mpd)(?:[?#]|$)|\/(?:manifest|playlist)(?:[/?#]|$)|[?&](?:format|type)=(?:m3u8|hls|dash|mpd)(?:&|$)/i;
      const segmentRe = /(?:\.m4s|\.ts|\.aac|\.cmfv|\.cmfa)(?:[?#]|$)|\/(?:segment|segments|seg|chunk|chunks|frag|fragment)[^/?#]*(?:[/?#]|$)|videoplayback\?.*(?:[?&](?:range|sq)=)/i;
      const mediaResourceSnapshot = () => {
        const entries = performance.getEntriesByType('resource');
        const manifests = new Set();
        const segments = new Set();
        for (const e of entries) {
          const name = e.name || '';
          if (manifestRe.test(name)) manifests.add(name);
          if (segmentRe.test(name)) segments.add(name);
        }
        return { manifests: [...manifests], segments: [...segments] };
      };

      const collect = () => {
        const resourceEntries = performance.getEntriesByType('resource');
        const xhrFetch = resourceEntries.filter(e => ['fetch','xmlhttprequest'].includes(e.initiatorType)).length;
        const apiLike = resourceEntries.filter(e => /(?:\/api\/|graphql|ajax|wp-json|\.json(?:\?|$)|_next\/data)/i.test(e.name)).length;
        const resourceUrls = [...new Set(resourceEntries.map(e => e.name || '').filter(u => /^https?:/i.test(u)))].slice(0, 1500);
        const resourceDetails = resourceEntries.filter(e => /^https?:/i.test(e.name || '')).slice(-1500).map(e => ({
          url: e.name || '', type: e.initiatorType || '', startTime: Math.round(e.startTime || 0),
          duration: Math.round(e.duration || 0), transferSize: e.transferSize || 0, decodedBodySize: e.decodedBodySize || 0
        }));
        const links = [...document.querySelectorAll('a[href]')].map(a => norm(a.getAttribute('href'))).filter(u => /^https?:/i.test(u));
        const clickish = [...document.querySelectorAll('button,[role="button"],a')];
        const loadMoreControls = clickish.filter(el => /(?:load|show|view)\s+more|se\s+flere|vis\s+flere|indlæs\s+flere|flere\s+(?:kommentarer|resultater|artikler|svar)/i.test((el.innerText || el.textContent || '').trim())).length;
        const paginationNoHref = clickish.filter(el => {
          const txt = (el.innerText || el.textContent || '').trim();
          const looks = /^(?:next|previous|næste|forrige|mere|more|\d{1,4})$/i.test(txt) || /next|prev|pagination/i.test(el.getAttribute('aria-label') || '');
          return looks && !(el instanceof HTMLAnchorElement && el.href);
        }).length;
        const imgs = [...document.images];
        const lazyDataOnly = imgs.filter(img => (img.dataset.src || img.dataset.lazySrc || img.dataset.original) && !img.getAttribute('src')).length;
        const crossOriginIframes = [...document.querySelectorAll('iframe[src]')].filter(f => { try { return new URL(f.src, location.href).origin !== location.origin; } catch { return false; } }).length;
        const scripts = [...document.scripts];
        const markup = document.documentElement?.innerHTML || '';
        const mediaResources = mediaResourceSnapshot();
        const mediaEls = [...document.querySelectorAll('video,audio')];
        const shadow = { roots: 0, textLength: 0, links: new Set() };
        const visitShadow = root => {
          for (const el of root.querySelectorAll?.('*') || []) {
            if (!el.shadowRoot) continue;
            shadow.roots++;
            try { shadow.textLength += (el.shadowRoot.textContent || '').trim().length; } catch {}
            for (const a of el.shadowRoot.querySelectorAll?.('a[href]') || []) {
              const u = norm(a.getAttribute('href')); if (/^https?:/i.test(u)) shadow.links.add(u);
            }
            visitShadow(el.shadowRoot);
          }
        };
        try { visitShadow(document); } catch {}

        const frameworks = [];
        if (window.__NEXT_DATA__ || /\/_next\//i.test(markup)) frameworks.push('Next.js');
        if (window.__NUXT__ || /\/_nuxt\//i.test(markup)) frameworks.push('Nuxt/Vue');
        if (document.querySelector('[ng-version]')) frameworks.push('Angular');
        if (/data-reactroot|react-dom/i.test(markup)) frameworks.push('React');
        if (document.querySelector('[class*="data-v-"], [data-v-app]') || /data-v-[0-9a-f]{6,}/i.test(markup)) frameworks.push('Vue');
        return {
          url: location.href,
          title: document.title,
          documentLanguage: (document.documentElement?.getAttribute('lang') || '').trim(),
          metaContentLanguage: (document.querySelector('meta[http-equiv="content-language" i]')?.getAttribute('content') || '').trim(),
          ogLocale: (document.querySelector('meta[property="og:locale" i]')?.getAttribute('content') || '').trim(),
          textSample: (document.body?.innerText || '').replace(/\s+/g, ' ').slice(0, 12000),
          textLength: document.body?.innerText?.length || 0,
          domHtmlLength: markup.length,
          linkCount: new Set(links).size,
          elementCount: document.body?.querySelectorAll('*').length || 0,
          links: [...new Set(links)].slice(0, 2500),
          buttonCount: document.querySelectorAll('button,[role="button"]').length,
          loadMoreControls,
          paginationNoHref,
          iframeCount: document.querySelectorAll('iframe').length,
          crossOriginIframes,
          scriptCount: scripts.length,
          xhrFetch,
          apiLike,
          resourceUrls,
          resourceDetails,
          shadowRootCount: shadow.roots,
          shadowTextLength: Math.min(shadow.textLength, 200000),
          shadowLinks: [...shadow.links].slice(0, 500),
          lazyStandard: document.querySelectorAll('[loading="lazy"]').length,
          lazyDataOnly,
          jsonLd: document.querySelectorAll('script[type="application/ld+json"]').length,
          frameworks: [...new Set(frameworks)],
          height: Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0),
          serviceWorkerControlled: !!navigator.serviceWorker?.controller,
          mediaElementCount: mediaEls.length,
          videoElementCount: mediaEls.filter(x => x.tagName === 'VIDEO').length,
          audioElementCount: mediaEls.filter(x => x.tagName === 'AUDIO').length,
          mediaBlobSources: mediaEls.filter(x => /^(?:blob|mediasource):/i.test(x.currentSrc || x.src || '')).length,
          streamingManifestCount: mediaResources.manifests.length,
          streamingSegmentCount: mediaResources.segments.length,
          streamingManifestUrls: mediaResources.manifests.slice(0, 12),
          streamingSegmentUrls: mediaResources.segments.slice(0, 20),
          spaHints: [
            (window.__NEXT_DATA__ || document.getElementById('__next')) && [...document.scripts].some(s => /\/_next\//i.test(s.src || '')) ? 'NEXT_ROUTER' : '',
            (window.__NUXT__ || document.getElementById('__nuxt')) && [...document.scripts].some(s => /\/_nuxt\//i.test(s.src || '')) ? 'NUXT_ROUTER' : '',
            document.querySelector('router-outlet') ? 'ANGULAR_ROUTER' : '',
          ].filter(Boolean),
          challenge: /just a moment|checking your browser|verify you are human|access denied|cloudflare ray id|captcha|bot detection/i.test((document.body?.innerText || '').slice(0, 12000)),
        };
      };

      const before = collect();
      if (!doScroll) {
        return {
          before,
          after: before,
          delta: { links: 0, xhrFetch: 0, apiLike: 0, text: 0, elements: 0, mutationAddedElements: 0, mutationAddedLinks: 0, mutationAddedText: 0, height: 0, heightRatio: 1, scrollSteps: 0, bottomLoads: 0, reachedStableBottom: true, safetyStop: false },
          interactions: { tested: 0, candidates: 0, results: [], dataLoadingClicks: 0, strongDataLoadingClicks: 0 },
          media: {
            detected: before.streamingManifestCount > 0 || before.streamingSegmentCount >= 3,
            mediaElements: before.mediaElementCount || 0,
            manifestRequests: before.streamingManifestCount || 0,
            segmentRequests: before.streamingSegmentCount || 0,
            manifests: before.streamingManifestUrls || [],
            segments: before.streamingSegmentUrls || [],
            playbackAttempted: 0, playbackStarted: 0, playbackNewManifests: 0, playbackNewSegments: 0,
            segmentsOnlyAfterPlayback: false, continuousSegments: (before.streamingSegmentCount || 0) >= 3,
          },
          spa: { detected: (before.spaHints || []).length > 0, observedRouting: false, hints: before.spaHints || [] },
        };
      }

      const oldX = scrollX, oldY = scrollY;
      const started = performance.now();
      const initialHeight = before.height;
      let steps = 0;
      let bottomLoads = 0;
      let stableBottomRounds = 0;
      let reachedStableBottom = false;
      let safetyStop = false;
      let lastBottomSnapshot = before;
      let resourceXhrFetch = 0;
      let resourceApiLike = 0;

      const addedElements = new Set();
      const addedRoots = new Set();
      const addedLinkUrls = new Set();
      const contentRoots = new Set();
      const contentLinkUrls = new Set();
      const adLike = el => {
        try {
          const host = el.closest?.('[data-ad],[data-ad-slot],[data-adunit],[aria-label*="advertisement" i],[aria-label*="sponsored" i],[class*="advertisement" i],[class*="ad-slot" i],[class*="adslot" i],[id*="ad-slot" i],[id*="adslot" i]');
          if (host) return true;
          const meta = `${el.id || ''} ${typeof el.className === 'string' ? el.className : ''}`;
          return /(?:^|[\s_-])(?:ads?|advert|advertisement|adslot|sponsor|sponsored)(?:$|[\s_-])/i.test(meta);
        } catch { return false; }
      };
      const observer = new MutationObserver(mutations => {
        for (const mutation of mutations) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType !== Node.ELEMENT_NODE) continue;
            addedRoots.add(node);
            addedElements.add(node);
            const crawlRelevantRoot = !adLike(node);
            if (crawlRelevantRoot) contentRoots.add(node);
            try {
              if (node.matches?.('a[href]')) {
                const u = norm(node.getAttribute('href'));
                if (/^https?:/i.test(u)) { addedLinkUrls.add(u); if (crawlRelevantRoot) contentLinkUrls.add(u); }
              }
              for (const child of node.querySelectorAll('*')) {
                addedElements.add(child);
                if (child.matches?.('a[href]')) {
                  const u = norm(child.getAttribute('href'));
                  if (/^https?:/i.test(u)) { addedLinkUrls.add(u); if (crawlRelevantRoot && !adLike(child)) contentLinkUrls.add(u); }
                }
              }
            } catch {}
          }
        }
      });
      try { observer.observe(document.documentElement, { childList: true, subtree: true }); } catch {}

      let perfObserver = null;
      try {
        perfObserver = new PerformanceObserver(list => {
          for (const e of list.getEntries()) {
            if (['fetch','xmlhttprequest'].includes(e.initiatorType)) resourceXhrFetch++;
            if (/(?:\/api\/|graphql|ajax|wp-json|\.json(?:\?|$)|_next\/data)/i.test(e.name || '')) resourceApiLike++;
          }
        });
        perfObserver.observe({ type: 'resource' });
      } catch {}

      try {
        // Start at the top so every lazy/intersection threshold between top and bottom can fire.
        scrollTo({ top: 0, left: oldX, behavior: 'auto' });
        await wait(120);

        while (steps < opts.maxSteps && performance.now() - started < opts.maxMs) {
          steps++;
          const docHeight = Math.max(document.documentElement.scrollHeight, document.body?.scrollHeight || 0);
          const viewport = Math.max(innerHeight || 0, 600);
          const maxY = Math.max(0, docHeight - viewport);
          const currentY = scrollY;
          const stepPx = Math.max(900, Math.floor(viewport * 1.35));
          const nextY = Math.min(maxY, currentY + stepPx);

          if (nextY > currentY + 20) {
            scrollTo({ top: nextY, left: oldX, behavior: 'auto' });
            await wait(180);
            continue;
          }

          // We are at the current bottom. Give the page time to append another batch.
          await wait(700);
          const snap = collect();
          const grew = snap.height > lastBottomSnapshot.height + 80
            || snap.linkCount > lastBottomSnapshot.linkCount + 1
            || snap.textLength > lastBottomSnapshot.textLength + 300
            || snap.elementCount > lastBottomSnapshot.elementCount + 8;
          const networkGrew = snap.xhrFetch > lastBottomSnapshot.xhrFetch || snap.apiLike > lastBottomSnapshot.apiLike;

          if (grew || networkGrew) {
            bottomLoads++;
            stableBottomRounds = 0;
            lastBottomSnapshot = snap;
            if (bottomLoads >= opts.maxBottomLoads) {
              safetyStop = true; // probably endless/infinite scroll; enough evidence has been collected
              break;
            }
            continue; // the bottom moved; keep scrolling through the newly appended content
          }

          stableBottomRounds++;
          lastBottomSnapshot = snap;
          if (stableBottomRounds >= opts.stableBottomRounds) {
            reachedStableBottom = true;
            break;
          }
        }

        if (!reachedStableBottom && (steps >= opts.maxSteps || performance.now() - started >= opts.maxMs)) safetyStop = true;
      } finally {
        observer.disconnect();
        try { perfObserver?.disconnect(); } catch {}
      }

      // One final settle catches requests triggered by the last intersection/bottom event.
      await wait(350);
      const after = collect();
      let mutationAddedText = 0;
      for (const el of addedRoots) {
        try { mutationAddedText += (el.innerText || el.textContent || '').trim().length; } catch {}
        if (mutationAddedText > 100000) { mutationAddedText = 100000; break; }
      }
      let contentMutationAddedText = 0;
      for (const el of contentRoots) {
        try { contentMutationAddedText += (el.innerText || el.textContent || '').trim().length; } catch {}
        if (contentMutationAddedText > 100000) { contentMutationAddedText = 100000; break; }
      }

      // Controlled interaction test. We intentionally EXCLUDE ordinary <a href>
      // navigation: following a normal URL is something Heritrix can already do and
      // must never count as high-fidelity evidence.
      const isVisible = el => {
        try {
          const r = el.getBoundingClientRect();
          const st = getComputedStyle(el);
          return r.width > 3 && r.height > 3 && st.display !== 'none' && st.visibility !== 'hidden' && Number(st.opacity || 1) > 0;
        } catch { return false; }
      };
      const normalHref = el => {
        const a = el.closest?.('a[href]');
        if (!a) return false;
        const raw = (a.getAttribute('href') || '').trim();
        if (!raw || raw === '#' || /^javascript:/i.test(raw)) return false;
        try {
          const u = new URL(raw, location.href);
          return /^https?:$/i.test(u.protocol);
        } catch { return false; }
      };
      const dangerous = el => {
        const txt = `${el.innerText || el.textContent || ''} ${el.getAttribute?.('aria-label') || ''} ${el.getAttribute?.('title') || ''}`.trim();
        if (/(?:delete|remove|logout|log\s*out|sign\s*out|login|sign\s*in|buy|purchase|checkout|order|pay|subscribe|unsubscribe|submit|save|confirm|accept|reject|cookie|consent|download|print|share|follow|like|report|block|book|reservation|slet|log\s*ud|log\s*ind|køb|betal|bestil|abonn|tilmeld|afmeld|send|gem|bekræft|accepter|afvis|samtykke|del\b)/i.test(txt)) return true;
        if (el.matches?.('input[type="submit"],button[type="submit"],[formaction]')) return true;
        if (el instanceof HTMLButtonElement && el.form && (!el.getAttribute('type') || el.type === 'submit')) return true;
        if (el.closest?.('form') || el.closest?.('a[download]')) return true;
        if (/(?:window\.)?location(?:\.href)?\s*=|location\.(?:assign|replace)\s*\(|window\.open\s*\(/i.test(el.getAttribute?.('onclick') || '')) return true;
        return false;
      };
      const descriptor = el => `${el.innerText || el.textContent || ''} ${el.getAttribute?.('aria-label') || ''} ${el.getAttribute?.('title') || ''} ${el.id || ''} ${el.className || ''}`.replace(/\s+/g, ' ').trim();
      const classifyControl = el => {
        const d = descriptor(el);
        const txt = (el.innerText || el.textContent || '').trim();
        if (/(?:load|show|view)\s+more|se\s+flere|vis\s+flere|indlæs\s+flere|hent\s+flere|flere\s+(?:kommentarer|resultater|artikler|svar|nyheder|indlæg)/i.test(d)) return 'load-more';
        const paginationContainer = el.closest?.('[class*="pagination" i],[class*="pager" i],[aria-label*="pagination" i],[aria-label*="paginering" i],nav[aria-label*="page" i],nav[aria-label*="side" i]');
        if (/^(?:next|previous|næste|forrige|mere|more)$/i.test(txt) || /(?:pagination|paginering|pager|next[-_ ]?page|prev(?:ious)?[-_ ]?page|næste\s+side|forrige\s+side)/i.test(d) || (/^\d{1,4}$/.test(txt) && paginationContainer)) return 'pagination';
        const tabContainer = el.closest?.('[role="tablist"],[class*="tabs" i],[class*="tab-list" i]');
        if (el.getAttribute?.('role') === 'tab' || tabContainer || /(?:^|[-_\s])tab(?:[-_\s]|$)|tabs?/i.test(`${el.getAttribute?.('aria-label') || ''} ${el.id || ''} ${el.className || ''}`)) return 'tab';
        if (el.getAttribute?.('aria-haspopup') === 'menu' || /menu[-_ ]?(?:toggle|button|trigger)|dropdown[-_ ]?(?:toggle|button|trigger)/i.test(d)) return 'menu';
        if (el.tagName === 'SUMMARY' || /accordion|disclosure|expand|collapse|fold/i.test(d) || el.hasAttribute?.('aria-expanded')) return 'accordion';
        return '';
      };

      const blockedAnchorHref = a => {
        if (!a) return false;
        const href = (a.getAttribute?.('href') || '').trim();
        return a.hasAttribute?.('download') || /^(?:blob:|data:|file:)/i.test(href) || /\.(?:pdf|docx?|xlsx?|pptx?|zip|rar|7z|csv|exe|msi|dmg|apk)(?:$|[?#])/i.test(href);
      };
      const blockDownloadClick = e => {
        const a = e.target?.closest?.('a');
        if (blockedAnchorHref(a)) { e.preventDefault(); e.stopImmediatePropagation(); }
      };
      const installNetworkSafety = () => {
        const originalFetch = window.fetch;
        const xhrOpen = XMLHttpRequest.prototype.open;
        const xhrSend = XMLHttpRequest.prototype.send;
        const originalBeacon = navigator.sendBeacon?.bind(navigator);
        const safeMethod = (method, url, body) => {
          method = String(method || 'GET').toUpperCase();
          if (['GET','HEAD','OPTIONS'].includes(method)) return true;
          const b = typeof body === 'string' ? body : '';
          return method === 'POST' && /graphql/i.test(String(url || '')) && !/\bmutation\b/i.test(b) && /(?:query|operationName|variables)/i.test(b);
        };
        try {
          window.fetch = function(input, init = {}) {
            const url = typeof input === 'string' ? input : input?.url || '';
            const method = init?.method || input?.method || 'GET';
            if (!safeMethod(method, url, init?.body)) return Promise.reject(new TypeError('Blocked by Crawler Choice safety policy'));
            return originalFetch.apply(this, arguments);
          };
          XMLHttpRequest.prototype.open = function(method, url, ...rest) { this.__ccMethod = method; this.__ccUrl = url; return xhrOpen.call(this, method, url, ...rest); };
          XMLHttpRequest.prototype.send = function(body) { if (!safeMethod(this.__ccMethod, this.__ccUrl, body)) { try { this.abort(); } catch {} return; } return xhrSend.call(this, body); };
          if (navigator.sendBeacon) navigator.sendBeacon = () => false;
        } catch {}
        return () => {
          try { window.fetch = originalFetch; XMLHttpRequest.prototype.open = xhrOpen; XMLHttpRequest.prototype.send = xhrSend; if (originalBeacon) navigator.sendBeacon = originalBeacon; } catch {}
        };
      };

      const allClickables = [...document.querySelectorAll('button,[role="button"],[role="tab"],summary,[aria-expanded],[aria-haspopup="menu"],input[type="button"],a')];
      const byType = new Map();
      for (const el of allClickables) {
        if (!isVisible(el) || normalHref(el) || dangerous(el) || el.disabled || el.getAttribute?.('aria-disabled') === 'true') continue;
        const type = classifyControl(el);
        if (!type || byType.has(type)) continue;
        byType.set(type, el);
      }
      const typeOrder = ['load-more','pagination','tab','accordion','menu'];
      const interactionResults = [];
      let dataLoadingClicks = 0;
      let strongDataLoadingClicks = 0;
      let observedRouting = false;
      let historyRouteEvents = 0;
      const originalPushState = history.pushState;
      const originalReplaceState = history.replaceState;
      const routeEvent = () => { historyRouteEvents++; observedRouting = true; };
      try {
        history.pushState = function(...a) { routeEvent(); return originalPushState.apply(this, a); };
        history.replaceState = function(...a) { routeEvent(); return originalReplaceState.apply(this, a); };
      } catch {}
      addEventListener('popstate', routeEvent);

      try {
        for (const type of typeOrder.slice(0, opts.clickMaxCandidates || 5)) {
          const el = byType.get(type);
          if (!el || !el.isConnected) continue;
          const clickBefore = collect();
          const beforeUrl = location.href;
          const beforeRouteEvents = historyRouteEvents;
          let localAddedElements = 0;
          let localAddedLinks = new Set();
          let localAddedText = 0;
          let localFetchCount = 0;
          let localApiCount = 0;
          let localDataFetchCount = 0;
          const localResourceUrls = [];
          const resourceNoise = /(?:google-analytics|googletagmanager|doubleclick|facebook\.com\/tr|hotjar|clarity\.ms|matomo|plausible|segment\.|sentry|telemetry|analytics|metrics|\/collect(?:\?|$)|beacon|adservice|adsystem|tracking)/i;
          let localPo = null;
          try {
            localPo = new PerformanceObserver(list => {
              for (const e of list.getEntries()) {
                if (!['fetch','xmlhttprequest'].includes(e.initiatorType)) continue;
                localFetchCount++;
                const name = e.name || '';
                if (/(?:\/api\/|graphql|ajax|wp-json|\.json(?:\?|$)|_next\/data)/i.test(name)) localApiCount++;
                if (!resourceNoise.test(name)) localDataFetchCount++;
                if (localResourceUrls.length < 8) localResourceUrls.push(name);
              }
            });
            localPo.observe({ type: 'resource' });
          } catch {}
          const mo = new MutationObserver(ms => {
            for (const m of ms) for (const n of m.addedNodes) {
              if (n.nodeType !== Node.ELEMENT_NODE) continue;
              localAddedElements++;
              try {
                localAddedText += (n.innerText || n.textContent || '').trim().length;
                if (n.matches?.('a[href]')) { const u = norm(n.getAttribute('href')); if (/^https?:/i.test(u)) localAddedLinks.add(u); }
                for (const a of n.querySelectorAll?.('a[href]') || []) { const u = norm(a.getAttribute('href')); if (/^https?:/i.test(u)) localAddedLinks.add(u); }
              } catch {}
            }
          });
          try { mo.observe(document.documentElement, { childList: true, subtree: true }); } catch {}
          const blockSubmit = e => { e.preventDefault(); e.stopImmediatePropagation(); };
          const originalOpenForProbe = window.open;
          const originalAnchorClickForProbe = HTMLAnchorElement.prototype.click;
          const restoreNetworkSafety = installNetworkSafety();
          try {
            document.addEventListener('submit', blockSubmit, true);
            document.addEventListener('click', blockDownloadClick, true);
            window.open = () => null;
            HTMLAnchorElement.prototype.click = function(...args) { if (blockedAnchorHref(this)) return; return originalAnchorClickForProbe.apply(this, args); };
          } catch {}
          try {
            el.scrollIntoView?.({ block: 'center', inline: 'nearest', behavior: 'auto' });
            await wait(100);
            el.click();
            await wait(opts.clickSettleMs || 1200);
          } catch {} finally {
            restoreNetworkSafety();
            try {
              document.removeEventListener('submit', blockSubmit, true);
              document.removeEventListener('click', blockDownloadClick, true);
              window.open = originalOpenForProbe;
              HTMLAnchorElement.prototype.click = originalAnchorClickForProbe;
            } catch {}
          }
          mo.disconnect();
          try { localPo?.disconnect(); } catch {}
          const clickAfter = collect();
          const networkDelta = Math.max(localFetchCount, Math.max(0, clickAfter.xhrFetch - clickBefore.xhrFetch));
          const apiDelta = Math.max(localApiCount, Math.max(0, clickAfter.apiLike - clickBefore.apiLike));
          const linkDelta = Math.max(0, clickAfter.linkCount - clickBefore.linkCount, localAddedLinks.size);
          const textDelta = Math.max(0, clickAfter.textLength - clickBefore.textLength, localAddedText);
          const elementDelta = Math.max(0, clickAfter.elementCount - clickBefore.elementCount, localAddedElements);
          const routeChanged = location.href !== beforeUrl || historyRouteEvents > beforeRouteEvents;
          if (routeChanged) observedRouting = true;
          const dataLoaded = localDataFetchCount > 0 || apiDelta > 0;
          const meaningfulContent = linkDelta >= 2 || textDelta >= 350 || elementDelta >= 8;
          const strong = dataLoaded && meaningfulContent;
          if (dataLoaded) dataLoadingClicks++;
          if (strong) strongDataLoadingClicks++;
          interactionResults.push({
            type,
            label: descriptor(el).slice(0, 120),
            dataLoaded, strong,
            xhrFetch: networkDelta, apiLike: apiDelta, dataFetch: localDataFetchCount,
            resourceUrls: localResourceUrls.slice(0, 5),
            addedLinks: linkDelta, addedText: Math.min(textDelta, 100000), addedElements: elementDelta,
            routeChanged,
            normalHrefExcluded: true,
          });

          // A same-document route transition is already useful SPA evidence and may
          // replace the DOM, invalidating the remaining element references. Stop here.
          if (routeChanged) break;
        }
      } finally {
        try { history.pushState = originalPushState; history.replaceState = originalReplaceState; } catch {}
        removeEventListener('popstate', routeEvent);
      }

      // Streaming-media probe. A media element by itself is not evidence. We look for
      // HLS/DASH manifests and repeated segment requests, and briefly start playback
      // muted in this disposable background tab to detect playback-triggered segments.
      const mediaBeforePlayback = mediaResourceSnapshot();
      let playbackAttempted = 0;
      let playbackStarted = 0;
      const originalMediaState = new Map();
      const rememberAndMute = media => {
        if (!media || originalMediaState.has(media)) return;
        originalMediaState.set(media, { muted: media.muted, volume: media.volume, paused: media.paused });
        try { media.muted = true; media.volume = 0; } catch {}
      };
      const currentMedia = [...document.querySelectorAll('video,audio')].slice(0, opts.mediaMaxElements || 2);
      currentMedia.forEach(rememberAndMute);

      const muteNewMedia = new MutationObserver(ms => {
        for (const m of ms) for (const n of m.addedNodes) {
          if (n.nodeType !== Node.ELEMENT_NODE) continue;
          if (n.matches?.('video,audio')) rememberAndMute(n);
          for (const media of n.querySelectorAll?.('video,audio') || []) rememberAndMute(media);
        }
      });
      try { muteNewMedia.observe(document.documentElement, { childList: true, subtree: true }); } catch {}

      try {
        for (const media of currentMedia) {
          playbackAttempted++;
          try {
            const playPromise = media.play?.();
            if (playPromise?.then) await Promise.race([playPromise.catch(() => {}), wait(700)]);
            await wait(250);
            if (!media.paused) playbackStarted++;
          } catch {}
        }

        // Some players do not create/initialize the media element until their own
        // JS play control is activated. Only click an obvious media-play control
        // inside a player/video/audio container, never a normal href.
        if (playbackStarted === 0) {
          const mediaPlay = [...document.querySelectorAll('button,[role="button"],[aria-label],[title]')].find(el => {
            if (!isVisible(el) || normalHref(el) || dangerous(el) || el.disabled || el.getAttribute?.('aria-disabled') === 'true') return false;
            const d = descriptor(el);
            if (!/(?:^|\b)(?:play|play video|play audio|start video|start audio|listen|afspil|lyt)(?:\b|$)/i.test(d)) return false;
            return !!el.closest?.('[class*="player" i],[id*="player" i],[class*="video" i],[id*="video" i],[class*="audio" i],[id*="audio" i],[data-player],figure');
          });
          if (mediaPlay) {
            playbackAttempted++;
            const blockSubmit = e => { e.preventDefault(); e.stopImmediatePropagation(); };
            const originalOpenForMedia = window.open;
            const originalAnchorClickForMedia = HTMLAnchorElement.prototype.click;
            const restoreNetworkSafety = installNetworkSafety();
            try {
              document.addEventListener('submit', blockSubmit, true);
              document.addEventListener('click', blockDownloadClick, true);
              window.open = () => null;
              HTMLAnchorElement.prototype.click = function(...args) { if (blockedAnchorHref(this)) return; return originalAnchorClickForMedia.apply(this, args); };
              mediaPlay.click();
            } catch {} finally {
              restoreNetworkSafety();
              try {
                document.removeEventListener('submit', blockSubmit, true);
                document.removeEventListener('click', blockDownloadClick, true);
                window.open = originalOpenForMedia;
                HTMLAnchorElement.prototype.click = originalAnchorClickForMedia;
              } catch {}
            }
            await wait(300);
            for (const media of [...document.querySelectorAll('video,audio')]) {
              rememberAndMute(media);
              if (!media.paused) playbackStarted++;
            }
          }
        }

        if (playbackAttempted > 0) await wait(opts.mediaPlaybackTestMs || 2200);
      } finally {
        muteNewMedia.disconnect();
        for (const [media, state] of originalMediaState) {
          try {
            if (state.paused && !media.paused) media.pause();
            media.muted = state.muted;
            media.volume = state.volume;
          } catch {}
        }
      }

      const mediaAfterPlayback = mediaResourceSnapshot();
      const beforeManifests = new Set(mediaBeforePlayback.manifests);
      const beforeSegments = new Set(mediaBeforePlayback.segments);
      const playbackNewManifests = mediaAfterPlayback.manifests.filter(x => !beforeManifests.has(x));
      const playbackNewSegments = mediaAfterPlayback.segments.filter(x => !beforeSegments.has(x));
      const continuousSegments = mediaAfterPlayback.segments.length >= 3;
      const segmentsOnlyAfterPlayback = playbackStarted > 0 && mediaBeforePlayback.segments.length === 0 && playbackNewSegments.length >= 2;
      const streamingDetected = mediaAfterPlayback.manifests.length > 0 || continuousSegments || segmentsOnlyAfterPlayback;

      const spaHints = [...new Set([...(before.spaHints || []), ...(after.spaHints || [])])];
      const strongStructuralSpa = spaHints.some(x => ['NEXT_ROUTER','NUXT_ROUTER','ANGULAR_ROUTER'].includes(x));

      // Content-polling heuristic. Repeated requests only matter when they resemble
      // content/API traffic, are not advertising/analytics noise, recur at a roughly
      // periodic cadence, and the page also accumulated meaningful crawl-relevant DOM.
      const trackerAdRe = /(?:google-analytics|googletagmanager|doubleclick|googlesyndication|adservice|adsystem|adnxs|taboola|outbrain|facebook\.com\/tr|connect\.facebook|hotjar|clarity\.ms|matomo|plausible|segment\.|sentry|newrelic|datadog|telemetry|analytics|metrics|\/collect(?:\?|$)|\/beacon(?:\?|$)|impression|tracking|pixel(?:\?|$))/i;
      const contentEndpointRe = /(?:\/api\/|graphql|wp-json|ajax|live|feed|articles?|posts?|comments?|results?|scores?|messages?|timeline|content|news|search|updates?)/i;
      const normalizePollUrl = raw => {
        try {
          const u = new URL(raw, location.href);
          u.hash = '';
          for (const [k] of [...u.searchParams]) {
            if (/^(?:_|t|ts|time|timestamp|cache|cachebuster|cb|rand|random|nonce|since|after|before|cursor|last|offset)$/i.test(k)) u.searchParams.set(k, '{dynamic}');
          }
          return u.href;
        } catch { return raw || ''; }
      };
      const pollGroups = new Map();
      for (const e of (after.resourceDetails || [])) {
        if (!['fetch','xmlhttprequest'].includes(e.type) || trackerAdRe.test(e.url || '')) continue;
        const key = normalizePollUrl(e.url);
        if (!pollGroups.has(key)) pollGroups.set(key, []);
        pollGroups.get(key).push(e);
      }
      const contentPolling = [];
      for (const [url, evs] of pollGroups) {
        if (evs.length < 3) continue;
        const times = evs.map(e => e.startTime || 0).sort((a,b)=>a-b);
        const gaps = times.slice(1).map((t,i)=>t-times[i]).filter(x=>x>=400);
        if (gaps.length < 2) continue;
        const avg = gaps.reduce((a,b)=>a+b,0)/gaps.length;
        const maxDev = Math.max(...gaps.map(x=>Math.abs(x-avg)));
        const periodic = avg >= 500 && maxDev <= Math.max(1200, avg * .75);
        const bodyBytes = evs.reduce((n,e)=>n+(e.decodedBodySize||e.transferSize||0),0);
        const sameSite = (()=>{ try { return new URL(url).hostname === location.hostname || new URL(url).hostname.endsWith('.'+location.hostname.replace(/^www\./,'')); } catch { return false; } })();
        const contentLike = contentEndpointRe.test(url) || bodyBytes >= 1500;
        const meaningfulMutation = contentLinkUrls.size >= 1 || contentMutationAddedText >= 250 || contentRoots.size >= 8;
        if (periodic && contentLike && meaningfulMutation && (sameSite || contentEndpointRe.test(url))) {
          contentPolling.push({ url, count: evs.length, avgIntervalMs: Math.round(avg), bytes: bodyBytes });
        }
      }

      scrollTo({ top: oldY, left: oldX, behavior: 'auto' });
      return {
        before,
        after,
        delta: {
          links: after.linkCount - before.linkCount,
          xhrFetch: Math.max(after.xhrFetch - before.xhrFetch, resourceXhrFetch),
          apiLike: Math.max(after.apiLike - before.apiLike, resourceApiLike),
          text: after.textLength - before.textLength,
          elements: after.elementCount - before.elementCount,
          mutationAddedElements: addedElements.size,
          mutationAddedLinks: addedLinkUrls.size,
          mutationAddedText,
          contentMutationAddedElements: contentRoots.size,
          contentMutationAddedLinks: contentLinkUrls.size,
          contentMutationAddedText,
          height: after.height - before.height,
          heightRatio: before.height ? after.height / before.height : 1,
          scrollSteps: steps,
          bottomLoads,
          reachedStableBottom,
          safetyStop,
          elapsedMs: Math.round(performance.now() - started),
          initialHeight,
          finalHeight: after.height,
        },
        interactions: {
          tested: interactionResults.length,
          candidates: byType.size,
          results: interactionResults,
          dataLoadingClicks,
          strongDataLoadingClicks,
        },
        media: {
          detected: streamingDetected,
          mediaElements: document.querySelectorAll('video,audio').length,
          manifestRequests: mediaAfterPlayback.manifests.length,
          segmentRequests: mediaAfterPlayback.segments.length,
          manifests: mediaAfterPlayback.manifests.slice(0, 12),
          segments: mediaAfterPlayback.segments.slice(0, 20),
          playbackAttempted,
          playbackStarted,
          playbackNewManifests: playbackNewManifests.length,
          playbackNewSegments: playbackNewSegments.length,
          segmentsOnlyAfterPlayback,
          continuousSegments,
        },
        polling: {
          detected: contentPolling.length > 0,
          candidates: contentPolling.slice(0, 8),
        },
        spa: {
          detected: observedRouting || strongStructuralSpa,
          observedRouting,
          hints: spaHints,
        },
      };
    },
    args: [!!scrollTest, scrollOptions],
  });
  return result?.result || null;
}

function combineResults(rawResults, renderedResults) {
  const renderMap = new Map(renderedResults.map(x => [canonicalKey(x.sample.url), x.rendered]));
  return rawResults.map(r => ({
    sample: r.sample,
    fetch: r.fetch,
    raw: r.raw,
    rendered: renderMap.get(canonicalKey(r.sample.url)) || null,
  }));
}
function canonicalKey(url) { try { const u = new URL(url); u.hash = ''; return u.href; } catch { return url; } }


function isNoiseResource(url) {
  return /(?:google-analytics|googletagmanager|doubleclick|googlesyndication|adservice|adsystem|adnxs|taboola|outbrain|facebook\.com\/tr|connect\.facebook|hotjar|clarity\.ms|matomo|plausible|segment\.|sentry|newrelic|datadog|telemetry|analytics|metrics|\/collect(?:\?|$)|\/beacon(?:\?|$)|impression|tracking|pixel(?:\?|$)|favicon|woff2?|ttf)(?:[/?#]|$)/i.test(url || '');
}

function runtimeOnlyResourceStats(raw, rendered, referenceUrl) {
  const staticSet = new Set((raw?.staticUrls || []).map(canonicalKey));
  const runtime = (rendered?.resourceUrls || []).filter(u => /^https?:/i.test(u) && !isNoiseResource(u) && !staticSet.has(canonicalKey(u)));
  let root = '';
  try { root = registrableDomain(new URL(referenceUrl).hostname); } catch {}
  const apiRe = /(?:\/api\/|graphql|ajax|wp-json|\.json(?:\?|$)|_next\/data|live|feed|articles?|posts?|comments?|results?|scores?|timeline|content)/i;
  const meaningfulRe = /(?:\.(?:jpe?g|png|webp|avif|pdf|m3u8|mpd|m4s|ts)(?:[?#]|$)|\/(?:page|pages|tile|tiles|image|images|document|publication|catalog|catalogue|katalog|media|video|audio)(?:[/?#._-]|$))/i;
  const sameDomain = runtime.filter(u => sameRegisteredDomain(u, root));
  const api = runtime.filter(u => apiRe.test(u));
  const meaningful = runtime.filter(u => apiRe.test(u) || meaningfulRe.test(u));
  return { total: runtime.length, sameDomain: sameDomain.length, api: api.length, meaningful: meaningful.length, urls: meaningful.slice(0, 12) };
}

function detectDecisiveBrowsertrixSample(rawRow, rendered) {
  const raw = rawRow?.raw;
  const rr = rendered?.after;
  if (!raw || !rr || rendered?.error) return null;
  const delta = rendered?.delta;
  const interactions = rendered?.interactions;
  const media = rendered?.media;
  const viewer = rendered?.viewer;

  if (delta) {
    const network = (delta.xhrFetch || 0) >= 1 || (delta.apiLike || 0) >= 1;
    const elements = Math.max(delta.elements || 0, delta.contentMutationAddedElements ?? delta.mutationAddedElements ?? 0);
    const links = Math.max(delta.links || 0, delta.contentMutationAddedLinks ?? delta.mutationAddedLinks ?? 0);
    const text = Math.max(delta.text || 0, delta.contentMutationAddedText ?? delta.mutationAddedText ?? 0);
    const meaningful = links >= 3 || text >= 1000 || (elements >= 35 && (delta.heightRatio || 1) >= 1.10);
    if (network && elements >= 15 && meaningful) return { code: 'SCROLL_FETCHES_ELEMENTS', text: 'Scrolling fetched and inserted substantial crawl-relevant content.' };
  }

  if (media?.detected && (media.manifestRequests || 0) >= 1 && (raw.streamingManifestHints || 0) === 0)
    return { code: 'PLAYER_JS_DISCOVERS_MANIFEST', text: 'JavaScript/player execution discovered a streaming manifest absent from the raw HTML.' };
  if (media?.segmentsOnlyAfterPlayback)
    return { code: 'PLAYBACK_STARTS_MEDIA_SEGMENTS', text: 'Streaming segments appeared only after playback was started.' };

  const decisiveClick = (interactions?.results || []).find(x => x.strong && ['load-more','pagination'].includes(x.type));
  if (decisiveClick) return { code: 'CLICK_LOADS_PAGINATED_CONTENT', text: `A non-href ${decisiveClick.type} control loaded and inserted new crawl-relevant content.` };
  if ((viewer?.strongClicks || 0) >= 1)
    return { code: 'INTERACTIVE_PAGE_FLIPPER', text: 'A non-href page-flipper/viewer control dynamically loaded the next page resource/state.' };

  return null;
}

function scoreEvidence(rows, sitemap, samples) {
  const evidence = [];
  let browsertrixScore = 0, heritrixScore = 0, strongCount = 0, decisiveCount = 0;
  const addB = (code, points, text, strong = false, decisive = false) => {
    if (evidence.some(e => e.code === code)) return;
    browsertrixScore += points; if (strong) strongCount++; if (decisive) decisiveCount++;
    evidence.push({ side: 'Browsertrix', code, points, text, strong, decisive });
  };
  const addH = (code, points, text) => {
    if (evidence.some(e => e.code === code)) return;
    heritrixScore += points;
    evidence.push({ side: 'Heritrix', code, points, text, strong: false });
  };

  let renderedComparable = 0, staticCoverage = 0, serverText = 0, noDynamic = 0;
  const aiSamples = [];

  for (const row of rows) {
    const raw = row.raw;
    const rr = row.rendered?.after;
    const delta = row.rendered?.delta;
    const interactions = row.rendered?.interactions;
    const media = row.rendered?.media;
    const spa = row.rendered?.spa;
    const viewer = row.rendered?.viewer;
    const polling = row.rendered?.polling;
    if (!raw || !rr) continue;
    renderedComparable++;

    const renderedInternal = countSameDomain(rr.links || [], row.fetch?.finalUrl || row.sample.url);
    const rawLinks = raw.internalLinkCount || 0;
    const rawText = raw.textLength || 0;
    const renderText = rr.textLength || 0;
    const linkGain = renderedInternal - rawLinks;
    const ratio = rawLinks ? renderedInternal / rawLinks : renderedInternal ? 99 : 1;
    const runtimeOnly = runtimeOnlyResourceStats(raw, rr, row.fetch?.finalUrl || row.sample.url);
    const shadowInternal = countSameDomain(rr.shadowLinks || [], row.fetch?.finalUrl || row.sample.url);
    const rawLinkSet = new Set((raw.links || []).map(canonicalKey));
    const shadowNewInternal = (rr.shadowLinks || []).filter(u => sameRegisteredDomain(u, registrableDomain(new URL(row.fetch?.finalUrl || row.sample.url).hostname)) && !rawLinkSet.has(canonicalKey(u))).length;

    const rawBlocked = (row.fetch?.status === 403 || row.fetch?.status === 429 || row.fetch?.status === 503 || raw.challenge);
    const browserLooksNormal = !rr.challenge && renderText >= 4000 && renderedInternal >= 10;
    if (rawBlocked && browserLooksNormal) {
      addB('BROWSER_BYPASSES_CHALLENGE', 7, 'Raw HTTP encounters a bot/WAF challenge or blocking while the browser receives normal crawl-relevant content.', true);
    }

    if ((rawLinks <= 8 && renderedInternal >= 30) || (linkGain >= 35 && ratio >= 1.5)) {
      addB('JS_GENERATED_LINKS', 6, 'Browser rendering creates substantially more internal links than the raw HTML.', true);
    }
    if (rawText < 2500 && renderText >= 8000 && runtimeOnly.api >= 1) {
      addB('CLIENT_RENDERED_FROM_RUNTIME_API', 7, 'The raw HTML is an application shell while browser execution obtains substantial visible content alongside API requests not discoverable in the initial response.', true);
    } else if (rawText < 2500 && renderText >= 8000 && (raw.scriptCount >= 4 || rr.scriptCount >= 4)) {
      addB('CLIENT_RENDERED_CONTENT', 6, 'The raw HTML resembles a client-side shell while browser execution creates substantially more text content.', true);
    }
    if (runtimeOnly.meaningful >= 3 && runtimeOnly.api >= 1) {
      addB('RUNTIME_ONLY_CONTENT_RESOURCES', 5, 'Browser execution requests multiple crawl-relevant resources that were not statically discoverable from the initial representation.', true);
    }
    if ((rr.shadowRootCount || 0) >= 1 && shadowNewInternal >= 5) {
      addB('SHADOW_DOM_DISCOVERY', 5, 'Open Shadow DOM contains multiple internal links not present in the raw HTML representation.', true);
    }
    if (polling?.detected && (polling.candidates || []).length) {
      addB('CONTENT_POLLING', 6, 'Repeated non-tracking API/content requests occur at a polling cadence while meaningful page content is changing.', true);
    }
    if (delta) {
      const scrollNetwork = delta.xhrFetch >= 1 || delta.apiLike >= 1;
      const addedElements = Math.max(delta.elements || 0, delta.contentMutationAddedElements ?? delta.mutationAddedElements ?? 0);
      const addedLinks = Math.max(delta.links || 0, delta.contentMutationAddedLinks ?? delta.mutationAddedLinks ?? 0);
      const addedText = Math.max(delta.text || 0, delta.contentMutationAddedText ?? delta.mutationAddedText ?? 0);
      const meaningfulAddedContent = addedLinks >= 3 || addedText >= 1000 || (addedElements >= 35 && delta.heightRatio >= 1.10);

      // Scroll-triggered insertion of crawl-relevant DOM backed by network activity
      // is direct evidence that a normal HTTP crawler will miss material unless the
      // browser interaction is reproduced.  Treat this as a decisive measured signal.
      if (scrollNetwork && addedElements >= 15 && meaningfulAddedContent) {
        addB('SCROLL_FETCHES_ELEMENTS', 9, 'Scrolling fetches and inserts new crawl-relevant elements via XHR/fetch; this is very strong high-fidelity evidence.', true, true);
      } else if (addedElements >= 20 && meaningfulAddedContent) {
        addB('SCROLL_ADDS_ELEMENTS', 7, 'Scrolling adds a substantial amount of new DOM content even though the corresponding network request could not be identified reliably.', true);
      } else if (addedLinks >= 8 && scrollNetwork) {
        addB('SCROLL_LOADS_DISCOVERY', 7, 'Scrolling triggers network requests and adds new crawl-relevant links.', true);
      }

      if ((delta.heightRatio >= 1.25 && addedLinks >= 5 && scrollNetwork) || ((delta.bottomLoads || 0) >= 2 && scrollNetwork && meaningfulAddedContent)) {
        addB('INFINITE_SCROLL', 4, 'The page continues fetching and inserting new batches at the bottom while scrolling.', true);
      }
    }
    if (media?.detected) {
      const rawManifestHints = raw.streamingManifestHints || 0;
      const manifestRequests = media.manifestRequests || rr.streamingManifestCount || 0;
      const segmentRequests = media.segmentRequests || rr.streamingSegmentCount || 0;

      // Strong signal 1: the browser has to execute the player/app before a streaming
      // manifest becomes visible on the network. The raw HTTP response exposed no HLS/DASH manifest URL.
      if (manifestRequests >= 1 && rawManifestHints === 0) {
        addB('PLAYER_JS_DISCOVERS_MANIFEST', 9, 'The browser/player discovers an HLS/DASH streaming manifest through JavaScript that is not exposed in the raw HTML.', true, true);
      }

      // Strong signal 2: segment traffic begins only after muted playback is started in
      // the disposable test tab. This directly demonstrates interaction-dependent media retrieval.
      if (media.segmentsOnlyAfterPlayback) {
        addB('PLAYBACK_STARTS_MEDIA_SEGMENTS', 9, 'Streaming media segments are requested only after playback starts.', true, true);
      } else if (media.continuousSegments && segmentRequests >= 3) {
        addB('CONTINUOUS_STREAMING_MEDIA', 7, 'Video or audio is fetched continuously as multiple streaming media segments.', true);
      }
    }

    if (interactions?.results?.length) {
      const strongClicks = interactions.results.filter(x => x.strong);
      const decisiveClicks = strongClicks.filter(x => ['load-more','pagination'].includes(x.type));
      if (decisiveClicks.length) {
        const kinds = [...new Set(decisiveClicks.map(x => x.type))].join(', ');
        addB('CLICK_LOADS_PAGINATED_CONTENT', 9, `A controlled ${kinds} interaction without normal href navigation triggers XHR/fetch and inserts new crawl-relevant content.`, true, true);
      } else if (strongClicks.length) {
        const kinds = [...new Set(strongClicks.map(x => x.type))].join(', ');
        addB('CLICK_TRIGGERS_DATA_LOADING', 7, `A controlled ${kinds} interaction without normal href navigation triggers data loading and new DOM content.`, true);
      } else if (interactions.dataLoadingClicks >= 1) {
        addB('CLICK_TRIGGERS_NETWORK', 3, 'A relevant non-href interaction triggers XHR/fetch, but not enough new crawl-relevant DOM content was measured for a strong signal.', false);
      }
    }
    if ((viewer?.strongClicks || 0) >= 1) {
      addB('INTERACTIVE_PAGE_FLIPPER', 9, 'An interactive document/page-flipper control without a normal href loads the next page as new image/page/tile resources or changes the viewer canvas/state.', true, true);
    }
    if ((rr.loadMoreControls || rr.paginationNoHref) >= 1 && rr.xhrFetch >= 1 && (linkGain > 5 || delta?.links > 0)) {
      addB('INTERACTION_ONLY_PAGINATION', 4, 'Load-more/pagination controls without normal href links exist together with dynamic network requests.', false);
    }
    if ((rr.lazyDataOnly >= 5 || raw.lazyDataSrc >= 5) && delta?.xhrFetch >= 1) {
      addB('DYNAMIC_LAZY_RESOURCES', 2, 'Multiple resources exist only in lazy-data attributes and are activated dynamically.', false);
    }
    if (rr.crossOriginIframes >= 2 && rawText < 3000) {
      addB('IFRAME_DEPENDENCY', 2, 'A substantial part of the page appears to depend on cross-origin iframes.', false);
    }
    if ((raw.frameworks.length || rr.frameworks.length) && (linkGain >= 10 || renderText > rawText * 1.5)) {
      addB('FRAMEWORK_WITH_DYNAMIC_DELTA', 1, 'A client-side framework is accompanied by a material difference between HTTP and browser results.', false);
    }

    if (rawLinks >= 25 && renderedInternal <= rawLinks * 1.2 + 5) staticCoverage++;
    if (rawText >= 5000 && renderText <= rawText * 1.35 + 1500) serverText++;
    if (delta && delta.xhrFetch === 0 && delta.apiLike === 0 && delta.links <= 3 && (delta.mutationAddedElements || 0) < 10 && (delta.elements || 0) < 10 && (delta.bottomLoads || 0) === 0) noDynamic++;

    aiSamples.push({
      role: row.sample.role,
      rawLinks,
      renderedLinks: renderedInternal,
      rawText,
      renderedText: renderText,
      xhrFetch: rr.xhrFetch,
      loadMoreControls: rr.loadMoreControls,
      paginationNoHref: rr.paginationNoHref,
      scrollDeltaLinks: delta?.links || 0,
      scrollDeltaXhrFetch: delta?.xhrFetch || 0,
      scrollDeltaElements: delta?.elements || 0,
      scrollMutationAddedElements: delta?.mutationAddedElements || 0,
      scrollMutationAddedLinks: delta?.mutationAddedLinks || 0,
      scrollContentMutationElements: delta?.contentMutationAddedElements || 0,
      scrollContentMutationLinks: delta?.contentMutationAddedLinks || 0,
      scrollContentMutationText: delta?.contentMutationAddedText || 0,
      scrollDeltaText: delta?.text || 0,
      scrollHeightRatio: Number((delta?.heightRatio || 1).toFixed(2)),
      scrollSteps: delta?.scrollSteps || 0,
      scrollBottomLoads: delta?.bottomLoads || 0,
      scrollReachedStableBottom: !!delta?.reachedStableBottom,
      scrollSafetyStop: !!delta?.safetyStop,
      lazyDataOnly: rr.lazyDataOnly,
      crossOriginIframes: rr.crossOriginIframes,
      frameworks: [...new Set([...(raw.frameworks || []), ...(rr.frameworks || [])])],
      runtimeOnlyResources: runtimeOnly.total,
      runtimeOnlyMeaningfulResources: runtimeOnly.meaningful,
      runtimeOnlyApiResources: runtimeOnly.api,
      shadowRootCount: rr.shadowRootCount || 0,
      shadowInternalLinks: shadowInternal,
      shadowNewInternalLinks: shadowNewInternal,
      contentPollingDetected: !!polling?.detected,
      contentPollingCandidates: polling?.candidates || [],
      rawWebSocketHints: raw.websocketHints || 0,
      rawEventSourceHints: raw.eventSourceHints || 0,
      rawGraphQlHints: raw.graphQlHints || 0,
      rawCursorPaginationHints: raw.cursorPaginationHints || 0,
      rawHttpStatus: row.fetch?.status || 0,
      rawChallenge: !!raw.challenge,
      browserChallenge: !!rr.challenge,
      interactionCandidates: interactions?.candidates || 0,
      interactionTests: interactions?.results || [],
      interactionStrongDataLoads: interactions?.strongDataLoadingClicks || 0,
      interactiveViewerDetected: !!viewer?.detected,
      interactiveViewerTests: viewer?.testedClicks || 0,
      interactiveViewerStrongClicks: viewer?.strongClicks || 0,
      interactiveViewerStrongFrames: viewer?.strongFrames || [],
      streamingMediaDetected: !!media?.detected,
      streamingManifestRequests: media?.manifestRequests || 0,
      streamingSegmentRequests: media?.segmentRequests || 0,
      streamingManifestMissingFromRawHtml: !!media?.manifestRequests && !(raw.streamingManifestHints || 0),
      mediaPlaybackAttempted: media?.playbackAttempted || 0,
      mediaPlaybackStarted: media?.playbackStarted || 0,
      playbackNewStreamingManifests: media?.playbackNewManifests || 0,
      playbackNewStreamingSegments: media?.playbackNewSegments || 0,
      streamingSegmentsOnlyAfterPlayback: !!media?.segmentsOnlyAfterPlayback,
      continuousStreamingSegments: !!media?.continuousSegments,
      spaDetected: !!spa?.detected,
      spaObservedRouting: !!spa?.observedRouting,
      spaHints: spa?.hints || [],
    });
  }

  if (renderedComparable >= 2 && staticCoverage >= Math.ceil(renderedComparable * 0.6)) addH('RAW_LINK_COVERAGE', 3, 'Raw HTML already contains nearly all internal links on the rendered samples.');
  if (renderedComparable >= 2 && serverText >= Math.ceil(renderedComparable * 0.6)) addH('SERVER_RENDERED_CONTENT', 2, 'The important text content is already server-rendered in HTML.');
  if (renderedComparable >= 2 && noDynamic >= Math.ceil(renderedComparable * 0.7)) addH('NO_SCROLL_DYNAMICS', 3, 'Scroll tests produced no substantial new discovery via XHR/fetch.');
  if (sitemap.entries.length >= 50 && samples.filter(s => s.role === 'section').length >= 2) addH('STRUCTURED_SITEMAP', 1, 'Sitemaps provide broad, structured URL discovery across multiple sections.');

  const spaDetected = rows.some(row => row.rendered?.spa?.detected);
  const streamingDetected = rows.some(row => row.rendered?.media?.detected);
  const aiPayload = {
    policy: 'Choose high fidelity only when JavaScript rendering or interaction is materially required to discover or obtain crawl-relevant content. First compare what is statically discoverable from raw HTML/CSS/JS/JSON with what the real browser actually requests and renders. Runtime-only content/API resources, a raw application shell populated by a runtime-only API, or meaningful Shadow DOM discovery are important evidence. Repeated polling counts only when tracker/ad endpoints are filtered out, the request pattern resembles content/API traffic, and meaningful page content changes. Scroll-triggered insertion of meaningful new DOM elements is strong high-fidelity evidence; when accompanied by fetch/XHR and new crawl-relevant content or links, treat it as high-confidence evidence. A controlled click on load-more, pagination, tab, accordion or menu that has NO normal href navigation and actually triggers fetch/XHR plus new crawl-relevant DOM content is strong evidence. Interactive document viewers/page-flippers are also decisive evidence when a non-href Next/forward control loads a new page image/tile/document resource, changes an image source or viewer canvas, or advances embedded viewer state; this must be detected inside accessible iframes as well as the top document. Streaming media is also strong Browsertrix evidence when the browser/player must execute JavaScript to discover an HLS/DASH manifest, when media segments begin only after playback starts, or when video/audio is fetched continuously as segments. A plain video/audio element or a direct MP4/MP3 URL alone is not streaming evidence. Ordinary <a href> navigation is never high-fidelity evidence. Framework presence, analytics XHR, standard lazy loading with real href/src, or a service worker alone are not enough. If unclear, choose Heritrix.',
    browsertrixScore,
    heritrixScore,
    strongSignalCount: strongCount,
    decisiveSignalCount: decisiveCount,
    sitemapUrlCount: sitemap.entries.length,
    sampledRoles: samples.map(s => s.role),
    samples: aiSamples,
    evidenceCodes: evidence.map(e => e.code),
  };

  return { browsertrixScore, heritrixScore, strongCount, decisiveCount, evidence, aiPayload, renderedComparable, spaDetected, streamingDetected };
}

function countSameDomain(urls, referenceUrl) {
  let root;
  try { root = registrableDomain(new URL(referenceUrl).hostname); } catch { return 0; }
  return new Set((urls || []).filter(u => sameRegisteredDomain(u, root))).size;
}

async function classifyWithNano(payload) {
  await ensureOffscreen();
  const response = await chrome.runtime.sendMessage({
    type: 'AI_CLASSIFY',
    target: 'offscreen',
    payload,
  });
  return response || { status: 'no-response' };
}

async function ensureOffscreen() {
  const path = 'offscreen.html';
  const url = chrome.runtime.getURL(path);
  const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [url] });
  if (contexts.length) return;
  if (offscreenCreating) return offscreenCreating;
  offscreenCreating = chrome.offscreen.createDocument({
    url: path,
    reasons: ['DOM_PARSER'],
    justification: 'Provide a document context for on-device Gemini Nano classification and DOMParser utilities.'
  });
  try { await offscreenCreating; } finally { offscreenCreating = null; }
}

function makeDecision(scored, ai) {
  const aiHigh = ai?.status === 'ok' && ai.needsHighFidelity === true && ai.confidence === 'high';

  // "High confidence" must be supported by measured evidence, not by Nano alone.
  // Either multiple strong independent signals agree, or one strong signal is corroborated
  // by Gemini Nano with high confidence. Otherwise default to Heritrix.
  const decisiveMeasuredSignal = scored.decisiveCount >= 1
    && scored.browsertrixScore >= 8;
  const multipleStrongSignals = scored.strongCount >= 2
    && scored.browsertrixScore >= 10
    && scored.browsertrixScore >= scored.heritrixScore + 4;
  const measuredPlusAi = scored.strongCount >= 1
    && scored.browsertrixScore >= 6
    && aiHigh;

  const highConfidenceHighFidelity = decisiveMeasuredSignal || multipleStrongSignals || measuredPlusAi;
  let confidence = 'low';
  if (highConfidenceHighFidelity) confidence = 'high';
  else if (scored.strongCount >= 1 || scored.browsertrixScore >= 4 || aiHigh) confidence = 'moderate';

  return {
    decision: highConfidenceHighFidelity ? 'Browsertrix' : 'Heritrix',
    confidence,
    highConfidenceHighFidelity,
    decisiveMeasuredSignal,
    multipleStrongSignals,
    measuredPlusAi,
  };
}

function buildReport(final, scored, ai, sitemap, samples, earlyExit = null, languageProfile = null) {
  const lines = [];
  lines.push(`Recommendation: ${final.decision} (high-fidelity confidence: ${final.confidence}).`);
  if (earlyExit) lines.push(`• Early exit: ${earlyExit.code} on ${earlyExit.sampleRole}; remaining browser samples were stopped.`);
  if (languageProfile) lines.push(`• Sitemap language: autodetected ${languageProfile.detected} (${languageProfile.source}); language-specific sitemap priority ${languageProfile.priorityLabel}${languageProfile.detected !== 'en' ? ', with English fallback' : ''}. Unmarked/default sitemaps remain eligible as neutral.`);

  const relevant = scored.evidence
    .filter(e => e.side === final.decision)
    .sort((a,b) => b.points - a.points)
    .slice(0, 5);
  for (const e of relevant) lines.push(`• ${e.text}`);

  if (final.decision === 'Heritrix' && !relevant.length) {
    lines.push('• No clear evidence shows that JavaScript/high-fidelity execution is required for discovery or content capture.');
  }

  lines.push(`• Test basis: ${samples.length} structural samples; ${sitemap.locations.length} sitemap locations found, ${sitemap.pools?.length || 0} sitemap candidate pools built, and ${sitemap.entries.length} content URLs extracted.`);

  if (ai?.status === 'ok') {
    lines.push(`• Gemini Nano: ${ai.needsHighFidelity ? 'detects a high-fidelity requirement' : 'does not detect a clear high-fidelity requirement'} (${ai.confidence || 'unknown'} confidence).`);
  } else if (ai?.status === 'skipped-decisive') {
    lines.push('• Gemini Nano: skipped because decisive measured Browsertrix evidence already made the crawler choice certain.');
  } else {
    const st = ai?.availability || ai?.status || 'unavailable';
    lines.push(`• Gemini Nano: ${st}; the conservative measurement-based classification was used.`);
  }

  if (final.decision === 'Heritrix') lines.push('• Rule: Browsertrix requires high confidence that high-fidelity crawling is materially needed; otherwise Heritrix is selected.');
  return lines.slice(0, 10);
}


async function mapLimitUntil(items, limit, fn) {
  const results = [];
  let next = 0;
  let stopped = false;
  async function worker() {
    while (!stopped) {
      const i = next++;
      if (i >= items.length || stopped) return;
      let res;
      try { res = await fn(items[i], i); } catch (error) { res = { value: { sample: items[i], rendered: { error: String(error) } }, stop: false }; }
      if (res?.value) results.push(res.value);
      if (res?.stop) { stopped = true; return; }
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return { results, stopped };
}

async function mapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let next = 0;
  async function worker() {
    while (true) {
      const i = next++;
      if (i >= items.length) return;
      out[i] = await fn(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return out;
}
