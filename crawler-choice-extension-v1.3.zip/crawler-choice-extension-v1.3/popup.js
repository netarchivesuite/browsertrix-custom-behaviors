let tabId = null;
let tabUrl = '';
let timer = null;
let incognitoAllowed = false;

const el = id => document.getElementById(id);

init().catch(err => {
  el('detail').textContent = String(err?.message || err);
});

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab?.id;
  tabUrl = tab?.url || '';
  el('domain').textContent = tabUrl ? new URL(tabUrl).hostname : 'Unknown page';
  const stored = await chrome.storage.local.get('crawlerChoiceSettings');
  const savedSamples = clampSamples(stored?.crawlerChoiceSettings?.sampleCount ?? 7);
  el('sample-count-input').value = String(savedSamples);
  el('sample-count-input').addEventListener('change', saveSampleSetting);

  incognitoAllowed = await chrome.extension.isAllowedIncognitoAccess();
  renderSecurityMode();
  el('analyze').disabled = !/^https?:/i.test(tabUrl) || !incognitoAllowed;
  el('analyze').addEventListener('click', start);
  el('guide').addEventListener('click', () => chrome.tabs.create({ url: chrome.runtime.getURL('guide.html') }));
  chrome.runtime.onMessage.addListener(msg => {
    if (msg?.type === 'STATE_UPDATED' && msg.tabId === tabId) render(msg.state);
  });
  await refresh();
  timer = setInterval(refresh, 500);
}

async function start() {
  el('analyze').disabled = true;
  const sampleCount = clampSamples(el('sample-count-input').value);
  el('sample-count-input').value = String(sampleCount);
  await saveSampleSetting();
  const response = await chrome.runtime.sendMessage({ type: 'START_ANALYSIS', tabId, url: tabUrl, sampleCount });
  if (!response?.ok) {
    el('detail').textContent = response?.error || 'Could not start the analysis.';
    el('analyze').disabled = !incognitoAllowed;
  } else {
    await refresh();
  }
}

async function refresh() {
  if (!tabId) return;
  const response = await chrome.runtime.sendMessage({ type: 'GET_STATE', tabId });
  if (response?.state) render(response.state);
}

function render(state) {
  const pct = Number(state.progress || 0);
  el('phase').textContent = state.phase || 'Ready';
  el('detail').textContent = state.detail || '';
  el('percent').textContent = `${pct}%`;
  el('bar').style.width = `${Math.max(0, Math.min(100, pct))}%`;
  el('bar').parentElement.classList.toggle('done', !!state.done && !!state.decision);

  const decision = el('decision');
  decision.className = 'decision';
  el('sample-count-input').disabled = !!state.running;
  if (state.running) {
    decision.textContent = 'Analyzing…';
    decision.classList.add('running');
    el('analyze').disabled = true;
  } else if (state.decision) {
    decision.textContent = state.decision;
    decision.classList.add(state.decision.toLowerCase());
    el('analyze').disabled = !incognitoAllowed;
  } else if (state.done) {
    decision.textContent = 'Error';
    decision.classList.add('error');
    el('analyze').disabled = !incognitoAllowed;
  } else {
    decision.textContent = 'Not analyzed';
    el('analyze').disabled = !incognitoAllowed;
  }

  const warning = el('warning');
  const warnings = Array.isArray(state.warnings) ? state.warnings.filter(Boolean) : (state.warning ? [state.warning] : []);
  if (warnings.length) {
    warning.textContent = warnings.join('\n\n');
    warning.hidden = false;
  } else {
    warning.textContent = '';
    warning.hidden = true;
  }

  if (state.scores) {
    const hf = state.scores.highFidelityConfidence ? ` · HF confidence ${state.scores.highFidelityConfidence}` : '';
    el('scores').textContent = `Browsertrix score ${state.scores.browsertrix} · Heritrix score ${state.scores.heritrix} · strong signals ${state.scores.strongSignals}${hf}`;
  } else {
    el('scores').textContent = '';
  }

  el('report').value = Array.isArray(state.report) ? state.report.slice(0, 10).join('\n') : '';
  const sitemapUrls = Array.isArray(state.sitemapUrls) ? state.sitemapUrls : [];
  el('sitemaps').value = sitemapUrls.join('\n');
  el('sitemap-count').textContent = sitemapUrls.length ? `(${sitemapUrls.length})` : '';
  const sampleRows = Array.isArray(state.samples) ? state.samples : [];
  el('sample-urls').value = sampleRows.map(s => `[${s.role}${s.status ? ` · ${s.status}` : ''}] ${s.url}`).join('\n');
  el('sample-count').textContent = sampleRows.length ? `(${sampleRows.length})` : '';
  if (sampleRows.length) {
    const roles = sampleRows.map(s => s.role).join(', ');
    el('samples').textContent = `Sample roles: ${roles}`;
  } else {
    el('samples').textContent = '';
  }
}


function clampSamples(value) {
  const n = Math.round(Number(value));
  return Number.isFinite(n) ? Math.max(5, Math.min(20, n)) : 7;
}

async function saveSampleSetting() {
  const sampleCount = clampSamples(el('sample-count-input').value);
  el('sample-count-input').value = String(sampleCount);
  await chrome.storage.local.set({ crawlerChoiceSettings: { sampleCount } });
}

function renderSecurityMode() {
  const box = el('security-mode');
  if (incognitoAllowed) {
    box.textContent = 'Security mode: fresh Incognito test window, download guard and HTML-only browser preflight.';
    box.classList.remove('required');
  } else {
    box.textContent = 'Incognito access is required. Enable “Allow in Incognito” for this extension in chrome://extensions, then reopen the popup.';
    box.classList.add('required');
  }
}
